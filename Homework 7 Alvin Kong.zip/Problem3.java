// Alvin Kong   Case ID: axk1079
// Homework 7 Problem 3 Part B
import java.util.Scanner;
public class Problem3 {
  public static void main (String [] args) {
    Scanner scan = new Scanner(System.in);
    int userRow;
    int userColumn;
    int[][] shipGrid = {{0,0,0,1,0},
                                 {1,1,0,1,0},
                                 {0,0,0,1,0},
                                 {0,0,0,0,0}};
      
    int[][] playerGrid = {{0,0,0,0,0},
                                    {0,0,0,0,0},
                                    {0,0,0,0,0},
                                    {0,0,0,0,0}};
    Grid.printGrid(playerGrid);
    System.out.println("Enter row (-1 to quit): ");
    userRow = scan.nextInt();
    while (userRow != -1) {
      System.out.println("Enter column: ");
      userColumn = scan.nextInt();
      if (shipGrid[userRow][userColumn] == 1) {
        System.out.println("Hit!");
        playerGrid[userRow][userColumn] = 1;
      }
      else {
        System.out.println("Miss");
        playerGrid[userRow][userColumn] = -1;
      }
      if (Grid.won(playerGrid, shipGrid) == true) {
        Grid.printGrid(playerGrid);
        System.out.println("Congratulations! You Won!");
        userRow = -1;
      }
      else {
        Grid.printGrid(playerGrid);
        System.out.println("Enter row (-1 to quit): ");
        userRow = scan.nextInt();
      }
    }
  }
}