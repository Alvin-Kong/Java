// Chris Fietkiewicz, Solution to HW 6
public class Statistics {
 private int years;
 private int points;

 public Statistics(int setyears, int setpoints) {
  years = setyears;
  points = setpoints;
 }

 public int getyears() {
  return years;
 }

 public int getpoints() {
  return points;
 }

 public boolean equals(Statistics s) {
  return (years == s.getyears() && points == s.getpoints());
 }

 public String toString() {
  return years + ", " + points;
 }
}