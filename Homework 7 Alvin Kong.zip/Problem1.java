// Alvin Kong   Case ID: axk1079
// Homework 7 Problem 1
import java.io.File;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Problem1 extends Application {
    private ChoiceBox<String> choice;
    private Button voteButton, resultsButton;
    private String current;
    String[] candidates = {"Billy", "Bob", "Joe", "John"};
    int[] votes;
    public void start(Stage primaryStage) {
        votes = new int[candidates.length];
        current = candidates[0];
        Label label = new Label("Select a candidate:");
        choice = new ChoiceBox<String>();
        choice.getItems().addAll(candidates);
        choice.setOnAction(this::processChoice);
        voteButton = new Button("Vote");
        resultsButton = new Button("Results");
        HBox buttons = new HBox(voteButton, resultsButton);
        buttons.setSpacing(10);
        buttons.setPadding(new Insets(15, 0, 0, 0));
        buttons.setAlignment(Pos.CENTER);
        voteButton.setOnAction(this::processButtonPush);
        resultsButton.setOnAction(this::processButtonPush);         
        VBox root = new VBox(label, choice, buttons);
        root.setPadding(new Insets(15, 15, 15, 25));
        root.setSpacing(10);
        root.setStyle("-fx-background-color: skyblue");
        Scene scene = new Scene(root, 300, 150);
        primaryStage.setTitle("Problem1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void processChoice(ActionEvent event) {
      current = candidates[choice.getSelectionModel().getSelectedIndex()];
    }
    
    public void processButtonPush(ActionEvent event) {
      String winner = candidates[0];
      int top = votes[0];
      if (event.getSource() == voteButton) {
        int i = choice.getSelectionModel().getSelectedIndex();
        votes[i] = votes[i] + 1; 
      }
      if (event.getSource() == resultsButton) {
        for (int i = 1; i < votes.length; i++) {
          if (votes[i] > top) {
            winner = candidates[i];
            top = votes[i];
          }
          else if (votes[i] == top) {
            winner = winner + ", " + candidates[i];
          }
        }
        System.out.println(winner + " (" + top + " votes)");
      }
  } 

  public static void main(String[] args) {
        launch(args);
    }
}
