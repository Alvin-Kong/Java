// Alvin Kong   Case ID: axk1079
// Homework 7 Problem 2
import java.util.Scanner;
public class Problem2 { 
  
  public static void main (String [] args) {
    Scanner scan = new Scanner(System.in);
    Player player1 = new Player("Ace", 10, 50);
    Player player2 = new Player("Crusher", 8, 85);
    Player players[] = {player1, player2};
    int userInput;
    boolean finishSearch = false;
    int n = 0;
    
    System.out.println("Chose (0=quit, 1=list, 2=search): ");
    userInput = scan.nextInt();
    while (userInput != 0) {
      switch (userInput) {
        case 1: for (int i = 0; i < players.length; i++) {
                       System.out.println(players[i]);
                     }
                     break;
        case 2: System.out.println("Enter name: ");
                     String userName = scan.nextLine();
                     userName = scan.nextLine();
                     System.out.println("Enter years: ");
                     int userYears = scan.nextInt();
                     System.out.println("Eneter points: ");
                     int userPoints = scan.nextInt();
                     Player player3 = new Player(userName, userYears, userPoints);
                     while (finishSearch == false) {
                       if (players[n].equals(player3)) {
                         System.out.println("Found!");
                         finishSearch = true;
                       }
                       else if (n < players.length) {
                         n++;
                       }
                       else if (n == players.length) {
                         System.out.println("Not Found");
                         finishSearch = true;
                       }
                     }
                     break;
                     
      }
      System.out.println("Chose (0=quit, 1=list, 2=search): ");
      userInput = scan.nextInt();
    }
  }
}