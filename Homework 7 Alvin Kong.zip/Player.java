// Chris Fietkiewicz, Solution to HW 6
public class Player {
 private String name;
 private Statistics stats;
 private static int totalYears = 0;

 public Player(String setName, int setYears, int setPoints) {
  name = setName;
  stats = new Statistics(setYears, setPoints);
  totalYears += setYears;
 }

 public String getName() {
  return name;
 }

 public Statistics getStats() {
  return stats;
 }

 public boolean equals(Player p) {
  return stats.equals(p.getStats()) && name.equals(p.getName());
 }

 public String toString() {
  return name + ", " + stats;
 }

 public static int getTotalYears() {
  return totalYears;
 }
}
