// Alvin Kong   Case ID: axk1079
// Homework 7 Problem 3 Part A
public class Grid {
  public static void printGrid (int[][] setPlayerField) {
    char[][] grid = new char[4][5];
    int[][] playerField = new int[4][5];
    playerField = setPlayerField;
    int x = 0;
    for (int row = 0; row < playerField.length; row++) {
      for (int col = 0; col < playerField[row].length; col++) {
        if (playerField[row][col] == 1) {
          grid[row][col] = 'X';
        }
        else if (playerField[row][col] == -1) {
          grid[row][col] = 'O';
        }
        else if (playerField[row][col] == 0) {
          grid[row][col] = ' ';
        }
      }
    }
    System.out.println("  0     1       2       3       4");
    for (int row = 0; row < grid.length; row++) {
      System.out.print(x);
      x++;
      for (int col=0; col < grid[row].length; col++) {
        System.out.print(grid[row][col] + "\t");
       }
      System.out.println();
     }
  }
  
  public static boolean won (int[][] playerField, int[][] shipField) {
    int hits = 0;
    for (int row = 0; row < shipField.length; row++) {
       for (int col = 0; col < shipField[row].length; col++) {
         if (shipField[row][col] == 1 && playerField[row][col] == 1) {
           hits++;
         }
       }
    }
    if (hits == 5) {
      return true;
    }
    else {
      return false;
    }
  }         
}