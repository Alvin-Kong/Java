// Alvin Kong   axk1079
// Homework 2
import java.util.Scanner;

public class Problem1Runner {
  public static void main (String [] args) {
    Scanner scan = new Scanner(System.in);
    
    Problem1 list1 = new Problem1(4);
    for (int i = 0; i < list1.getCapacity(); i++) {
      System.out.println("Enter a number: ");
      int userNum = scan.nextInt();
      list1.add(userNum);
    }
    
    list1.print();
    
    Problem1 list2 = new Problem1(4);
    for (int i = 0; i < list2.getCapacity(); i++) {
      System.out.println("Enter a number: ");
      int userNum = scan.nextInt();
      list2.add(userNum);
    }
    
    list2.print();
    
    Problem1.intersection(list1, list2);
    
  }
}