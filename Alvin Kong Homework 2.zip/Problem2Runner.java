// Alvin Kong   axk1079
// Homeowork 2
import java.util.Scanner;

public class Problem2Runner {
  public static void main (String [] args) {
    Scanner scan = new Scanner(System.in);
    
    Problem2 list1 = new Problem2(4);
    for (int i = 0; i < list1.getCapacity(); i++) {
      System.out.println("Enter a number: ");
      int userNum = scan.nextInt();
      list1.add(userNum);
    }
    
    list1.print();
    
    Problem2 list2 = new Problem2(4);
    for (int i = 0; i < list2.getCapacity(); i++) {
      System.out.println("Enter a number: ");
      int userNum = scan.nextInt();
      list2.add(userNum);
    }
    
    list2.print();
    
    Problem1.intersection(list1, list2);
    
  }
}