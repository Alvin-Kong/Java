// Alvin Kong   axk1079
// Homework 2
public class Problem2 implements Cloneable {
   private IntNode head;
   private int manyNodes;   

   public Problem2( ) {
      head = null;
      manyNodes = 0;
   }
        
   public void add(int element) {  
     if (countOccurrences(element) < 1) {
       head = new IntNode(element, head);
       manyNodes++;
     }
   }
   
    public void addAll(Problem2 addend) {
      IntNode[ ] copyInfo;
      if (addend.manyNodes > 0) {
         copyInfo = IntNode.listCopyWithTail(addend.head);
         copyInfo[1].setLink(head);
         head = copyInfo[0];
         manyNodes += addend.manyNodes;
      }
   }
    
    public void print() {
     for (int i = 0; i < manyNodes.length; i++) {
       System.out.print(+ " ");
     }
     System.out.println();
   }

   public int countOccurrences(int target) {
      int answer;
      IntNode cursor;

      answer = 0;
      cursor = IntNode.listSearch(head, target);
      while (cursor != null) { 
         answer++;
         cursor = cursor.getLink( );
         cursor = IntNode.listSearch(cursor, target);
      }
      return answer;
   }

   public int grab( )  {
      int i;
      IntNode cursor;
      
      if (manyNodes == 0)
         throw new IllegalStateException("Bag size is zero");
         
      i =  (int)(Math.random( ) * manyNodes) + 1;
      cursor = IntNode.listPosition(head, i);
      return cursor.getData( );
   }
                            
   public int size( ) {
      return manyNodes;
   }
   
   public static Problem2 union(Problem2 b1, Problem2 b2) {       
      Problem2 answer = new Problem2( );
      
      answer.addAll(b1);
      answer.addAll(b2);     
      return answer;
   }
      
}
           
