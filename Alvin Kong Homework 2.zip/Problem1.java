// Alvin Kong   axk1079
// Homework 2
import java.util.ArrayList;
public class Problem1 implements Cloneable {
   private int[ ] data;
   private int manyItems; 
   
   public Problem1( ) {
      final int INITIAL_CAPACITY = 10;
      manyItems = 0;
      data = new int[INITIAL_CAPACITY];
   }
     
   public Problem1(int initialCapacity) {
     if (initialCapacity < 0) {
         throw new IllegalArgumentException
         ("The initialCapacity is negative: " + initialCapacity);
     }
      data = new int[initialCapacity];
      manyItems = 0;
   }
        
   public void add(int element) {
      if (manyItems == data.length) {
         ensureCapacity((manyItems + 1)*2);
      }
      if (countOccurrences(element) < 1) {
        data[manyItems] = element;
        manyItems++;
      }
      else {
        System.out.println("This number is already in the list");
      }
   }

   public int countOccurrences(int target) {
      int answer;
      int index;
      
      answer = 0;
      for (index = 0; index < manyItems; index++) {
        if (target == data[index]) {
            answer++;
        }
      }
      return answer;
   }

   public void ensureCapacity(int minimumCapacity) {
      int[ ] biggerArray;
      
      if (data.length < minimumCapacity) {
         biggerArray = new int[minimumCapacity];
         System.arraycopy(data, 0, biggerArray, 0, manyItems);
         data = biggerArray;
      }
   }
   
   public void print() {
     for (int i = 0; i < data.length; i++) {
       System.out.print(data[i] + " ");
     }
     System.out.println();
   }

   private int get(int index) {
     try {
         return data[index];
      }
      catch (Exception e) {  
         throw new RuntimeException
         ("This index could not be found");
      }
   }
   
   public int getCapacity( ) {
      return data.length;
   }

   public static Problem1 intersection(Problem1 b1, Problem1 b2) {
     Problem1 answer = new Problem1();
     
     for (int i = 0; i < b1.getCapacity(); i++) {
       if (b2.countOccurrences(b1.get(i)) > 0) {
         int index = 0;
         answer.data[index] = b1.get(i);
       }
     } 
     return answer;
   }
      
}
           
