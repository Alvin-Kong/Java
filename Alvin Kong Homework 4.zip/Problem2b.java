// Alvin Kong   axk1079
// Homework 4 Problem 2

import java.util.Scanner;

public class Problem2b {

    public static void navigate () {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a direction for a step (s=straight, l=left, r=right, q=quit: ");
        String step = scan.nextLine();

        if (step.equals("q")) {
            System.out.println("Turn 180 degrees");
        }

        else {
            switch (step) {
                case "s":
                    navigate();
                    System.out.println("Take a step and remain straight");
                    break;
                case "l":
                    navigate();
                    System.out.println("Take a step and turn right");
                    break;
                case "r":
                    navigate();
                    System.out.println("Take a step and turn left");
                    break;
            }
        }
    }

    public static void main (String [] args) {
        navigate();
    }
}



