// Alvin Kong   axk1079
// Homework 4 Problem 2

import java.util.Stack;
import java.util.Scanner;

public class Problem2a {
    public static void main(String[] args) {
        boolean quit = false;
        Stack<String> store = new Stack<String>( );
        Scanner scan = new Scanner(System.in);

        while (!quit) {
            System.out.println("Enter a direction for a step (s=straight, l=left, r=right, q=quit: ");
            String step = scan.nextLine();
            if (step.equals("q")) {
                quit = true;
            }
            else {
                store.push(step);
            }
        }

        System.out.println("Turn 180 degrees");

        while (!store.empty()) {
            switch (store.pop()) {
                case "s":
                    System.out.println("Take a step and remain straight");
                    break;
                case "l":
                    System.out.println("Take a step and turn right");
                    break;
                case "r":
                    System.out.println("Take a step and turn left");
                    break;
            }
        }

        System.out.println("Done!");
    }
}




