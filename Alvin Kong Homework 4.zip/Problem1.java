// Alvin Kong   axk1079
// Homework 4 Problem 1
public class Problem1 {
    public static void main (String [] args) {
        int [] numbers = new int[20];
        fractal(0, 20, numbers);
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Array index: " + i + ", value: " + numbers[i]);
        }
    }

    public static void fractal(int left, int right, int [] numArray) {
        final int STOP = 1;
        int mid = (right + left) / 2;

        if (right - left == STOP) {
            return;
        }
        else {
            numArray[mid] = right - left;
            fractal(left, mid, numArray);
            fractal(mid, right, numArray);
        }
    }


}



