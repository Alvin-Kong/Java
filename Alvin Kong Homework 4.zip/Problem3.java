// Alvin Kong   axk1079
// Homework 4 Problem 3

import java.io.IOException;

public class Problem3 {
   public static void main(String[ ] args) {
      EasyReader stdin = new EasyReader(System.in);
      int n;
      double x;
      
      System.out.println("I can calculate the value of x raised to an integer power.");
      
      do {
         x = stdin.doubleQuery("The value of x: ");
         n = stdin.intQuery("The integer power: ");
         System.out.println("Answer using the power method: " + power(x,n));
         System.out.println("Answer using the pow   method: " + pow(x,n));
      }

      while (stdin.query("Do you want to try other values?"));
      
      System.out.println("Thank you beary much.");
   }

   public static double power(double x, int n) {
      double product; // The product of x with itself n times
      int count;

      if (x == 0 && n <= 0) {
         throw new IllegalArgumentException("x is zero and n=" + n);
      }

      if (n >= 0) {
         product = 1;
         for (count = 1; count <= n; count++) {
            product = product * x;
         }

         return product;
      }

      else {
         return 1 / power(x, -n);
      }
   }

   public static double pow(double x, int n) {
      if (x == 0 && n <= 0) {
         throw new IllegalArgumentException("x is zero and n=" + n);
      }
      else if (n == 0) {
         return 1;
      }
      else if ((n > 0) && (n % 2 == 1)) {
         return x * pow(x, n - 1);
      }
      else if ((n > 0) && (n % 2 == 0)) {
         double partial = pow(x, n/2);
         return partial * partial;
      }
      else {
         return 1 / pow(x, -n);
      }
   }
    
}
