// Alvin Kong   axk1079
// Homework 5 Problem 3
public class Problem3 implements Cloneable {
    private IntBTNode root = null;

    public static void main(String[] args) {
        Problem3 tree = new Problem3();
        tree.add(6);
        tree.add(1);
        tree.add(3);
        tree.add(2);
        tree.add(9);
        tree.add(7);
        tree.add(5);
        tree.add(4);
        tree.add(8);
        tree.remove(4);
        tree.remove(1);
        tree.remove(6);
        System.out.println("in order:");
        tree.inorderPrint();
        System.out.println();
        System.out.println("pre order:");
        tree.preorderPrint();
        System.out.println();
        System.out.println("post order:");
        tree.postorderPrint();
    }

    public void add(int element) {
        IntBTNode cursor = root;
        boolean inserted = false;

        if (cursor == null) {
            root = new IntBTNode(element, null, null);
        }

        else {
            while (inserted == false) {
                if (cursor.getData() >= element) {
                    cursor = cursor.getLeft();
                    if (cursor == null) {
                        IntBTNode newNode = new IntBTNode(element, null, null);
                        cursor.setLeft(newNode);
                        inserted = true;
                    }
                }
                else {
                    cursor = cursor.getRight();
                    if (cursor == null) {
                        IntBTNode newNode = new IntBTNode(element, null, null);
                        cursor.setLeft(newNode);
                        inserted = true;
                    }
                }
            }

            cursor = new IntBTNode(element, null, null);
        }
    }

    private boolean remove(int target) {
        boolean found = false;
        boolean exit = false;
        IntBTNode cursor = root;
        IntBTNode parentOfCursor = null;

        while (cursor.getData() != target && exit == false){
            if (cursor.getData() == target) {
                found = true;
                exit = true;
            }
            else if (cursor == null) {
                found = false;
                exit = true;
            }

            else if (cursor.getData() > target) {
                parentOfCursor = cursor;
                cursor = cursor.getLeft();
            }

            else {
                parentOfCursor = cursor;
                cursor = cursor.getRight();
            }
        }

        if (target == root.getData()) {
            root = root.getRight();
            found = true;
        }

        if (parentOfCursor.getLeft() == cursor) {
            parentOfCursor.setLeft(cursor.getRight());
            return true;
        }
        else {
            parentOfCursor.setRight(cursor.getRight());
            return true;
        }

        cursor.setData(cursor.getLeft( ).getRightmostData());
        cursor.getLeft().removeRightmost();
        return found;
    }

    public void inorderPrint() {
        root.inorderPrint();
    }

    public void preorderPrint() {
        root.preorderPrint();
    }

    public void postorderPrint() {
        root.postorderPrint();
    }

}

