// Author: Alvin Kong   Case ID: axk1079
import java.util.Scanner;
public class HW1_3 {
  public static void main(String[] args) {
    double initialVelocity;
    double H1, H2, H3, H4;
    Scanner scan = new Scanner(System.in);
    System.out.print("Enter the initial velocity: ");
    initialVelocity = scan.nextDouble();
    H1 = (0.5 * -9.8 * (0.0 * 0.0)) + (initialVelocity * 0.0);
    System.out.println("At 0.0 seconds, the height is " + H1);
    H2 = (0.5 * -9.8 * (0.1 * 0.1)) + (initialVelocity * 0.1);
    System.out.println("At 0.1 seconds, the height is " + H2);
    H3 = (0.5 * -9.8 * (0.2 * 0.2)) + (initialVelocity * 0.2);
    System.out.println("At 0.2 seconds, the height is " + H3);
    H4 = (0.5 * -9.8 * (0.3 * 0.3)) + (initialVelocity * 0.3);
    System.out.println("At 0.3 seconds, the height is " + H4);
  }
}