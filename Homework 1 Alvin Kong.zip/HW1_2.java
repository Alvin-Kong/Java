// Author: Alvin Kong   Case ID: axk1079
import java.util.Scanner;
public class HW1_2 {
  public static void main(String[] args) {
    double length;
    double radius;
    int bottles;
    Scanner scan = new Scanner(System.in);
    System.out.print("Enter the box length: ");
    length = scan.nextDouble();
    System.out.print("Enter the bottle radius: ");
    radius = scan.nextDouble();
    bottles = ((int) (length / (radius * 2))) * ((int) (length / (radius * 2)));
    System.out.println("A square box of length " + length + " can hold " + bottles + " of radius " + radius);
  }
}