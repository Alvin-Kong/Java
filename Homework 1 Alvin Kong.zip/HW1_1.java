// Author: Alvin Kong  Case ID: axk1079
public class HW1_1 {
  public static void main(String[] args) {
    final double EXAMGRADE1 = 90;
    final double HOMEWORKGRADE1 = 85;
    final double LABGRADE1 = 100;
    final double QUIZGRADE1 = 100;
    final double EXAMGRADE2 = 100;
    final double HOMEWORKGRADE2 = 98;
    final double LABGRADE2 = 100;
    final double QUIZGRADE2 = 100;
    double examAverage;
    double homeworkAverage;
    double labAverage;
    double quizAverage;
    double overallScore;
    examAverage = (EXAMGRADE1 + EXAMGRADE2) / 2;
    homeworkAverage = (HOMEWORKGRADE1 + HOMEWORKGRADE2) / 2;
    labAverage = (LABGRADE1 + LABGRADE2) / 2;
    quizAverage = (QUIZGRADE1 + QUIZGRADE2) / 2;
    overallScore = ((examAverage * 0.5) + (homeworkAverage * 0.15) + (labAverage * 0.15) + (quizAverage * 0.2)); 
    System.out.println("Exam average is " + examAverage);
    System.out.println("Homework average is " + homeworkAverage);
    System.out.println("Lab average is " + labAverage);
    System.out.println("Quiz average is " + quizAverage);
    System.out.println("Overall score is " + overallScore);
  }
}