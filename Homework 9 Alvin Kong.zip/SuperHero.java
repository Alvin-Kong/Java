// Chris Fietkiewicz. Solution to Lab 8.
public class SuperHero extends Person {
  private int topSpeed;
  
  public SuperHero(int setSpeed) {
    topSpeed = setSpeed;
  }
  
  public String toString() {
    return "Name: " + name + ", Top speed: " + topSpeed;
  }
}