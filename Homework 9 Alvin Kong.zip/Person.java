// Alvin Kong   Case ID: axk1079
// Homeowork 9 Problem 1B
public class Person <T>{
  protected String name;
  
  public void setName(String setName) {
    name = setName;
  }
  
  public String getName() {
    return name;
  }
  
  public int compareTo(Person person) {
    String nameCompare = person.getName();
    return name.compareTo(nameCompare);
  }
  
  public boolean equals(Person person) {
    if (name.equals(person.getName())) {
      return true;
    }
    else {
      return false;
    }
  }
}