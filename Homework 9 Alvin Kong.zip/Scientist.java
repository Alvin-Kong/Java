// Chris Fietkiewicz. Solution to Lab 8.
public class Scientist extends Person{
  private int IQ;
  
  public Scientist(int setIQ) {
    IQ = setIQ;
  }
  
  public String toString() {
    return "Name: " + name + ", IQ: " + IQ;
  }
}