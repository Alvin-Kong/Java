// Alvin Kong   Case ID: axk1079
// Homework 9 Problem 2
public class SortingRevised {
    public void selectionSort(int[] list) {
        int min;
        int var;
        for (int index = 0; index < list.length-1; index++) {
            min = index;
            int count = index + 1;
            for (int scan = index+1; scan < list.length; scan++) {
              if (list[scan] > list[min]) {
                    min = scan;
              }
            }
            String[] symbolArray = new String[list.length];
            for (int i = 0; i < list.length; i++) {
              if (list[i] == list[min]) {
                symbolArray[i] = "X ";
              }
              else if (list[i] == list[index]) {
                symbolArray[i] = "O ";
              }
              else {
                symbolArray[i] = "  ";
              }
            }
            System.out.println("   " + symbolArray);
            var = list[min];
            list[min] = list[index];
            list[index] = var;
            System.out.println(count + ". " + list);
        }
        System.out.println("Final array: " + list);
    }
    
    public void insertionSort (int[] list) {
        for (int index = 1; index < list.length; index++) {
            int key = list[index];
            int position = index;
            int count = index;
            String[] symbolArray = new String[list.length];
             for (int i = 0; i < list.length; i++) {
              if (list[i] == list[index]) {
                symbolArray[i] = "X ";
              }
              else if (list[i] == list[position]) {
                symbolArray[i] = "O ";
              }
              else {
                symbolArray[i] = "  ";
              }
            }
            System.out.println("   " + symbolArray);
            while (position > 0 && key > list[position-1]) {
                list[position] = list[position-1];
                position--;
            }
            list[position] = key;
            System.out.println(count + ". " + list);
        }
        System.out.println("Final array: " + list);
    }
}
