// Alvin Kong   Case ID:axk1079
// Homework 9 Problem 2
public class Problem2 {
  public static void main (String [] args) {
    int[] numArray = {90, 30, 88, 55, 12};
    SortingRevised sorting = new SortingRevised();
    System.out.println("Selection Sorting:");
    sorting.selectionSort(numArray);
    System.out.println("Insertion Sorting:");
    sorting.insertionSort(numArray); 
  }
}