import java.util.Scanner;
public class Problem1{
  public static void main (String [] args) {
    Scanner scan = new Scanner(System.in);
    boolean isFound = false;
    System.out.println("Enter name: ");
    String userName = scan.nextLine();
    Person[] people = new Person[4];
    people[0] = new Scientist(200);
    people[0].setName(userName);
    people[1] = new SuperHero(100);
    people[1].setName("Superman");
    people[2] = new Scientist(150);
    people[2].setName("Megamind");
    people[3] = new SuperHero(300);
    people[3].setName("Batman");
    String[] names = new String[people.length];
    for (int i = 0; i < people.length; i++) {
      names[i] = people[i].getName();
    }
    Sorting<String> sort = new Sorting<String>();
    sort.selectionSort(names);
    System.out.println("Enter name to search: ");
    Searching<String> search = new Searching<String>();
    String userTarget = scan.nextLine();
    for (int i = 0; i < names.length; i++) {
      if (search.binarySearch(names, userTarget) == people[i].getName()) {
        System.out.println("Found... " + people[i]);
        isFound = true;
      }
    }
      if (isFound = false) {
        System.out.println("That name was not found.");
      }
  } 
}