// Alvin Kong   Case ID: axk1079
// Homework 3_1
public class Creature {
  private String name;
  private int energy;
  private int energyIn;
  private int energyOut;
  
  public Creature (String setName, int setEnergy, int setEnergyIn, int setEnergyOut) {
   name = setName;
   energy = setEnergy;
   energyIn = setEnergyIn;
   energyOut = setEnergyOut;
  }
  
  public int getEnergy() {
    return energy;
  }
  
  public void eat() {
    energy = energy + energyIn;
  }
  
  public void exercise() {
    energy = energy - energyOut;
  }
    
  public String toString() {
    return name + " has " + energy+ " energy units";
  }
}
