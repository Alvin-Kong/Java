// Alvin Kong   Case ID: axk1079
// Homework 3_1
public class Problem1{
  public static void main(String[] args) {
    Creature fuzzy = new Creature("Fuzzy", 50, 10, 10);
    Creature floofy = new Creature("Floofy", 25, 5, 10);
    System.out.println(fuzzy);
    System.out.println(floofy);
    fuzzy.exercise();
    floofy.exercise();
    System.out.println("Exercising...");
    System.out.println(fuzzy);
    System.out.println(floofy);
    fuzzy.eat();
    floofy.eat();
    System.out.println("Eating...");
    System.out.println(fuzzy);
    System.out.println(floofy);
  }
}

