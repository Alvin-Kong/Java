// Alvin Kong   Case ID: axk1079
// Homework 3_3
public class BasketballStats {
  private String player;
  private int points;
  private int steals;
  private int assists;
  
  public BasketballStats (String setName, int setPoints, int setSteals, int setAssists) {
   player = setName;
   points = setPoints;
   steals = setSteals;
   assists = setAssists;
  }
  
  public String getPlayer() {
    return player;
  }
  
  public int getPoints() {
    return points;
  }

  public int getSteals() {
    return steals;
  }
                         
  public int getAssists() {
    return assists;
  }
                          
  public void twoPointer() {
    points = points + 2;
  }
  
  public void threePointer() {
    points = points + 3;
  }
    
  public void stealBall() {
    steals = steals + 1;
  }
    
  public void assistBall() {
    assists = assists + 1;
  }
                          
  public String toString() {
    return player + " has " + points + " points, " + steals + " steals, and " + assists + " assists";
  }
}
