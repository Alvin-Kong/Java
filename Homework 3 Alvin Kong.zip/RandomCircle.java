// Alvin Kong   Case ID: axk1079
//Homeowork 3_2
import java.util.Random;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class RandomCircle {
  public int width;
  public int height;
  private int radius;
  private int randomX;
  private int randomY;
  
  public RandomCircle (int sceneWidth, int sceneHeight) {
    width = sceneWidth;
    height = sceneHeight;
  }
  
  public int getWidth() {
    return width;
  }
  
  public int getHeight() {
    return height;
  }
  
  public Circle makeCircle (int setRadius, Color setColor) {
    radius = setRadius;
    Color color = setColor;
    Random generator = new Random();
    randomX = generator.nextInt(width - (radius * 2)) + radius;
    randomY = generator.nextInt(height - (radius * 2)) + radius;
    Circle circle = new Circle(randomX, randomY, radius);
    circle.setFill(color);
    return circle;
  }
}