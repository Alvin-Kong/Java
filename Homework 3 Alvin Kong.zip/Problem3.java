// Alvin Kong   Case ID: axk1079
// Homework 3_3
public class Problem3 {
  public static void main(String[] args) {
    BasketballStats Curry = new BasketballStats("Curry", 0, 0, 00);
    BasketballStats LeBron = new BasketballStats("Lebron", 0, 0, 0);
    System.out.println(Curry);
    System.out.println(LeBron);
    Curry.threePointer();
    LeBron.twoPointer();
    Curry.stealBall();
    LeBron.twoPointer();
    Curry.assistBall();
    LeBron.assistBall();
    System.out.println(Curry);
    System.out.println(LeBron);
    Curry.threePointer();
    LeBron.assistBall();
    Curry.threePointer();
    LeBron.twoPointer();
    Curry.assistBall();
    LeBron.stealBall();
    Curry.twoPointer();
    System.out.println(Curry.getPlayer() + " has " + Curry.getPoints() + " points, " + Curry.getSteals() + " steals, and " + Curry.getAssists() + " assists");
    System.out.println(LeBron.getPlayer() + " has " + LeBron.getPoints() + " points, " + LeBron.getSteals() + " steals, " + LeBron.getAssists() + " assists");
  }
}

