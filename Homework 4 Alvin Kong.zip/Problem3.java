// Alvin Kong   Case ID: axk1079
// HW4_3
import java.util.Scanner;
public class Problem3 {
  public static void main (String args[]) {
    int sum;
    int cardValue;
    int userInput = 1;
    Scanner scan = new Scanner(System.in);
    cardValue = (int) (Math.random() * 10) + 1;
    sum = cardValue;
    System.out.println("New card: " + cardValue);
    while (sum <= 22 && userInput == 1) {
      System.out.println("Stand (0) or hit (1)?");
      userInput = scan.nextInt();
      if (userInput == 0) {
        System.out.println("Your total is " + sum);
      }
      if (userInput == 1) {
        cardValue = (int) (Math.random() * 10) + 1;
        System.out.println("New card: " + cardValue);
        sum = sum + cardValue;
      }
    }
    if (sum > 21) {
      System.out.println("Your total is " + sum);
      System.out.println("You busted!");
    }
  }
}