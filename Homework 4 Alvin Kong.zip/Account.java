// Alvin Kong   Case ID: axk1079
// HW4_1
import java.util.Scanner;
public class Account {
  Scanner scan = new Scanner(System.in);
  private String password;
  private boolean loginStatus;

  public Account(String setPassword) {
    password = setPassword;
  }
  
  public void login() {
    System.out.println("Enter password: ");
    String passwordInput = scan.nextLine();
    if (passwordInput.equals (password)) {
      loginStatus = true;
      System.out.println("You are logged in!");
    }
    else {
      System.out.println("Incorrect password.");
    }
  }
  
  public void logout() {
    loginStatus = false;
    System.out.println("You are logged out.");
  }
  
  public void changePassword() {
    if (loginStatus == true) {
      System.out.print("Enter new password");
      String newPassword = scan.nextLine();
      password = newPassword;
      System.out.println("Password changed.");
    }
    else {
      System.out.println("Sorry, you are not logged in");
    }
  }

}
