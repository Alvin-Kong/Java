// Alvin Kong   Case ID: axk1079
// HW4_1
import java.util.Scanner;
public class Problem1 {
  public static void main(String args[]) {
    Scanner scan = new Scanner(System.in);
    boolean quitStatus = false;
    Account account = new Account("Woohoo!");
    while (quitStatus == false) {
      System.out.print("Enter command: ");
      String userInput = scan.nextLine();
      if (userInput.equals ("quit")) {
        quitStatus = true;
      }
      else if (userInput.equals ("login")) {
        account.login();
      }
      else if (userInput.equals ("change")) {
        account.changePassword();
      }
      else if (userInput.equals ("logout")) {
        account.logout();
      }
      else {
        System.out.println("Unrecognized command");
      }
    }
  }
}