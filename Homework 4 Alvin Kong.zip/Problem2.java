// Alvin Kong   Case ID: axk1079
// HW4_2
import java.util.Scanner;
public class Problem2 {
  public static void main (String args[]) {
    int count = 0;
    int number1;
    int number2;
    int answer;
    int guess;
    Scanner scan = new Scanner(System.in);

    while (count < 3) {
      number1 = (int) (Math.random() * 10);
      number2 = (int) (Math.random() * 10);
      answer = number1 + number2;
      System.out.println("What is " + number1 + " + " + number2 + " ?");
      guess = scan.nextInt();
      if (guess == answer) {
        System.out.println("Correct!");
        count ++;
      }
      else {
        System.out.println("Sorry, that's incorrect");
        count = 0;
      }
    }
    System.out.println("Three in a row!");
  }
}