// Alvin Kong   axk1079
// Homework 3 Problem 7

import java.util.Queue;
import java.util.Scanner;
import java.util.LinkedList;

public class Problem7 {
    public static void main(String[] args) {
        Queue<Integer> clock = new LinkedList<>();
        Queue<String> waitingList = new LinkedList<>();
        Scanner scan = new Scanner(System.in);
        boolean quit = false;

        while (quit == false) {
            System.out.println("Enter name (or 'quit'): ");
            String name = scan.nextLine();
            if (name.equals("quit")) {
                quit = true;
            }

            else {
                System.out.println("Enter current time: ");
                int time = scan.nextInt();
                clock.add(time);
                waitingList.add(name);

                if (waitingList.size() > 1) {
                    for (int i = 0; i < waitingList.size(); i++) {
                        int endTime = clock.peek() + 100;

                        if (time > endTime) {
                            System.out.println(waitingList.peek() + " is done.");
                            clock.remove();
                            waitingList.remove();
                        }

                        else {
                            System.out.println(name + " can have it at " + endTime);
                        }
                    }
                    System.out.println(name + " can have it now!");
                }

                else {
                    System.out.println(name + " can have it now!");
                    clock.add(time);
                    waitingList.add(name);
                }

            }
        }
    }
}

