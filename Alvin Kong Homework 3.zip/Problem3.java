// Alvin Kong   axk1079
// Homework 3 Problem 3

import java.util.Stack;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Problem3 {
    public static void main(String[ ] args)
    {
        Scanner scan = new Scanner(System.in);
        String expression;
        double answer;

        System.out.println("Please type an arithmetic expression made from");
        System.out.println("unsigned numbers and the operations + - * /.");
        System.out.println("The expression must be fully parenthesized.");

        System.out.print("Your expression: ");
        expression = scan.nextLine( );
        try {
            answer = evaluate(expression);
        }
        catch (Exception e) {
        System.out.println("Error." + e.toString( ));
        }
    }


    public static double evaluate(String s) {
        Scanner input = new Scanner(s);
        ArrayStack<Double> numbers = new ArrayStack<Double>( );
        LinkedStack<Character> operations = new LinkedStack<Character>( );
        String next;
        char first;

        while (input.hasNext( ))
        {
            if (input.hasNext(UNSIGNED_DOUBLE))
            {
                next = input.findInLine(UNSIGNED_DOUBLE);
                numbers.push(new Double(next));
            }
            else
            {
                next = input.findInLine(CHARACTER);
                first = next.charAt(0);

                switch (first)
                {
                    case '+':
                    case '-':
                    case '*':
                    case '/':
                        operations.push(first);
                        break;
                    case ')':
                        evaluateStackTops(numbers, operations);
                        break;
                    case '(':
                        break;
                    default :
                        throw new IllegalArgumentException("Illegal character");
                }
            }

            System.out.print("Character: " + next + " ");
            System.out.print("Numbers = ");
            numbers.print();
            System.out.print("Operators = ");
            operations.print();
            System.out.println();

        }
        if (numbers.size( ) != 1)
            throw new IllegalArgumentException("Illegal input expression");
        return numbers.pop( );
    }


    public static void evaluateStackTops(ArrayStack<Double> numbers, LinkedStack<Character> operations) {
        double operand1, operand2;

        if ((numbers.size( ) < 2) || (operations.isEmpty( )))
            throw new IllegalArgumentException("Illegal expression");
        operand2 = numbers.pop( );
        operand1 = numbers.pop( );

        // Carry out an action based on the operation on the top of the stack.
        switch (operations.pop( ))
        {
            case '+': numbers.push(operand1 + operand2);
                break;
            case '-': numbers.push(operand1 - operand2);
                break;
            case '*': numbers.push(operand1 * operand2);
                break;
            case '/': // Note: A division by zero results in POSTIVE_INFINITY or
                // NEGATIVE_INFINITY.
                numbers.push(operand1 / operand2);
                break;
            default : throw new IllegalArgumentException("Illegal operation");
        }
    }

    public static final Pattern CHARACTER =
            Pattern.compile("\\S.*?");
    public static final Pattern UNSIGNED_DOUBLE =
            Pattern.compile("((\\d+\\.?\\d*)|(\\.\\d+))([Ee][-+]?\\d+)?.*?");
}
