// Alvin Kong   axk1079
// Homework 3 Problem 1

import java.util.Stack;
import java.util.Scanner;

public class isBalanced {
    public static void main(String[ ] args) {
        Scanner scan = new Scanner(System.in);
        String expression;

        System.out.println("Please type a string containing various kinds");
        System.out.println("of parentheses ( ). I'll check whether the parentheses are balanced.");
        System.out.print("Your string: ");
        expression = scan.nextLine();
        if (counting(expression) == false) {
            System.out.println("That is balanced.");
        }
        else {
            System.out.println("That is not balanced.");
        }
    }

    public static boolean counting(String expression) {

        final char LEFT_NORMAL  = '(';
        final char RIGHT_NORMAL = ')';

        int counter = 0;
        boolean failed = false;

        for (int i = 0; i < expression.length(); i++) {
            switch (expression.charAt(i)) {
                case LEFT_NORMAL:
                    counter++;
                    break;
                case RIGHT_NORMAL:
                    counter--;
                    break;
            }
        }

        if (counter == 0) {
            failed = false;
        }

        else {
            failed = true;
        }

        return failed;
    }
}
