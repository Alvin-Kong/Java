// Alvin Kong   axk1079
// Homework 3 Problem 6

import java.util.Stack;
import java.util.Scanner;

public class Problem6 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String expression;

        System.out.println("Please type an postfix arithmetic expression:");
        System.out.print("Your expression: ");
        expression = scan.nextLine();
        System.out.println(evaluate(expression));
    }

    public static double evaluate(String expression) {
        Stack<Double> numbers = new Stack<Double>();
        double answer;

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (Character.isDigit(c)) {
                double value = Character.getNumericValue(c);
                numbers.push(value);
            }

            else {
                switch (c) {
                    case '+':
                        answer = numbers.pop() + numbers.pop();
                        numbers.push(answer);
                        break;
                    case '-':
                        answer = numbers.pop() - numbers.pop();
                        numbers.push(answer);
                        break;
                    case '*':
                        answer = numbers.pop() * numbers.pop();
                        numbers.push(answer);
                        break;
                    case '/':
                        answer = numbers.pop() / numbers.pop();
                        numbers.push(answer);
                        break;
                    default:
                        throw new IllegalArgumentException("Illegal character");
                }
            }
        }

        return numbers.pop();
    }
}
