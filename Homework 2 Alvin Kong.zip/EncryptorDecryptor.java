// Author: Alvin Kong   Case ID: axk1079

import java.util.Scanner;

public class  EncryptorDecryptor {
  
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    char letter1 = 'a';
    char replace1 = 'x';
    char letter2 = ' ';
    char replace2 = 'w';
    char letter3 = 't';
    char replace3 = 'd';
    char letter4 = 's';
    char replace4 = 'k';
    char letter5 = 'h';
    char replace5 = 'o';
    String encryption1, encryption2, encryption3, encryption4, encryption5;
    String decryption1, decryption2, decryption3, decryption4, decryption5;
    System.out.println("Enter a message");
    String message = scan.nextLine();
    encryption1 = message.replace(letter1, replace1);
    encryption2 = encryption1.replace(letter2, replace2);
    encryption3 = encryption2.replace(letter3, replace3);
    encryption4 = encryption3.replace(letter4, replace4);
    encryption5 = encryption4.replace(letter5, replace5);
    System.out.println("Encrypted: " + encryption5);
    decryption1 = message.replace(replace1, letter1);
    decryption2 = decryption1.replace(replace2, letter2);
    decryption3 = decryption2.replace(replace3, letter3);
    decryption4 = decryption3.replace(replace4, letter4);
    decryption5 = decryption4.replace(replace5, letter5);
    System.out.println("Decrypted: " + decryption5);
  }
  
}