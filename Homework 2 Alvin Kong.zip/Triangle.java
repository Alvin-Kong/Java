// Author: Alvin Kong   Case ID: axk1079

import java.util.Scanner;
import java.text.DecimalFormat;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Triangle extends Application {
  
  public void start (Stage primaryStage) {
    Scanner scan = new Scanner(System.in);
    DecimalFormat fmt = new DecimalFormat("0.###");
    double width;
    double height;
    double hypotenuse;
    System.out.println("Enter width:");
    width = scan.nextDouble();
    System.out.println("Enter height");
    height = scan.nextDouble();
    hypotenuse = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));
    Line widthLine = new Line(15, 185, 15 + width, 185);
    Line heightLine = new Line(15, 185, 15, 185 - height);
    Line hypotenuseLine = new Line(15, 185 - height, 15 + width, 185);
    Text hypotenuseValue = new Text(((15 + width) / 2) + 10, (185 - (height / 2)), fmt.format(hypotenuse));
    Group root = new Group(widthLine, heightLine, hypotenuseLine, hypotenuseValue);
    Scene scene = new Scene(root, 300, 200);
    primaryStage.setTitle("Triangle JavaFX");
    primaryStage.setScene(scene);
    primaryStage.show();
  }
 
  public static void main(String[] args) {
    launch(args);
  }
  
}
    