// Author: Alvin Kong   Case ID: axk1079

import java.util.Random;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Circles extends Application {
  
  public void start (Stage primaryStage) {
    Random generator = new Random();
    final int WIDTH = 200;
    final int HEIGHT = 100;
    int randomX;
    int randomY;
    randomX = generator.nextInt(160) + 20;
    randomY = generator.nextInt(60) + 20;
    Circle circle1 = new Circle(randomX, randomY, 20);
    circle1.setFill(Color.BLUE);
    randomX = generator.nextInt(160) + 20;
    randomY = generator.nextInt(60) + 20;
    Circle circle2 = new Circle(randomX, randomY, 20);
    circle2.setFill(Color.RED);
    randomX = generator.nextInt(160) + 20;
    randomY = generator.nextInt(60) + 20;
    Circle circle3 = new Circle(randomX, randomY, 20);
    circle3.setFill(Color.GREEN);
    randomX = generator.nextInt(160) + 20;
    randomY = generator.nextInt(60) + 20;
    Circle circle4 = new Circle(randomX, randomY, 20);
    circle4.setFill(Color.YELLOW);
    randomX = generator.nextInt(160) + 20;
    randomY = generator.nextInt(60) + 20;
    Circle circle5 = new Circle(randomX, randomY, 20);
    circle5.setFill(Color.CYAN);
    Group root = new Group(circle1, circle2, circle3, circle4, circle5);
    Scene scene = new Scene(root, WIDTH, HEIGHT);
    primaryStage.setTitle("Circles JavaFX");
    primaryStage.setScene(scene);
    primaryStage.show();
  }
  
  public static void main(String[] args) {
    launch(args);
  }
  
}
    