// Alvin Kong   axk1079
//Homework 1
public class Example1 {
    public static void main(String[] args) {
        long startTime;
        long intervalTime;
        long x = 0;
        long N = 10000L;
        long divider = N / 6;
        int interval = 1;
        startTime = System.currentTimeMillis();
        for (long k = 0; k < 6; k++) {
          for (long i = 0; i < N; i++) {
            x = x + 1;
            }
          intervalTime = System.currentTimeMillis() - startTime;
          System.out.println("N = " + x + ", time = " + intervalTime + " msec");
        }
    }
}

