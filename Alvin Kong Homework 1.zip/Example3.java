// Alvin Kong   axk1079
public class Example3 {
    public static void main(String[] args) {
        long startTime;
        long intervalTime;
        long x = 0;
        long N = 100L;
        
        startTime = System.currentTimeMillis();
        for (long k = 0; k < 6; k++) {
          for (long i = 0; i < N; i++) {
            x = x + 1;
          }
          for (long i = 0; i < N; i++) {
            for (long j = 0; j < N; j++) {
                x = x + 1;
            }
          }
          intervalTime = System.currentTimeMillis() - startTime;
          System.out.println("N = " + x + ", time = " + intervalTime + " msec");
        }
    }
}

