// Alvin Kong
// Homework 1
import java.util.Random; 
public class Problem5 {
  public static void main(String[] args) {
    Random rand = new Random();
    int N = 50;
    int iteration = 1;
    int nArray[];
    nArray = new int[N];
    
    for (int k = 0; k < N; k++) {
      nArray[k] = rand.nextInt(N);
    }
    
    for (int i = 0; i < 10; i++) {
        int target = rand.nextInt(N); 
        int iterations = search(nArray, target);
        System.out.println("Trial #" + i + ", target = " + target + ", " + iterations + " iterations");
    }
    
    public static int search(int[] data, int target) {
      int i;
      for (i = 0; i < data.length; i++ ) {
        if (data[i] == target) {
          return i;
        }
        i++;
        return i;
      }
    }
  }
}