// Alvin Kong   axk1079
// Homework 7 Problem 5

public class ChainedTableRunner {
    public static void main (String [] args) {
        ChainedTable cTable = new ChainedTable(3);
        cTable.put(1, "Hi");
        cTable.put(4, "Bye");
        cTable.put(1,"Hello");
        cTable.put(2, "Greetings");
        cTable.print();
    }
}
