// Alvin Kong   axk1079
// Homework 7 Problem 4

public class DoubleTableRunner {
    public static void main (String [] args) {
        DoubleTable dTable = new DoubleTable(8);
        dTable.put(1, "Hi");
        dTable.put(5, "Bye");
        dTable.put(3,"Greetings");
        dTable.put(11, "Hello");
        dTable.put(13, "See you later");
        dTable.print();
    }
}
