// Alvin Kong   axk1079
// Homework 7 Problem 6

import java.util.*;
import java.io.*;

public class Problem6 {
    public static void main (String [] args) {
        StringTable dictionary = new StringTable(7);
        ArrayList<String> textArray = new ArrayList<String>();
        Scanner scanner, refer;
        int counter = 0;
        int wordCounter = 0;
        int missing = 0;
        String unused = "";

        try {
            refer = new Scanner(new FileReader("dictionary.txt"));
            scanner = new Scanner(new FileReader("text.txt"));
        }
        catch (FileNotFoundException e) {
            System.err.println(e);
            return;
        }

        while (refer.hasNext()) {
            String word = refer.next();
            word = word.replaceAll("[^a-zA-Z ]", "").toLowerCase();
            dictionary.put(counter, word);
            counter++;
        }

        dictionary.print();

        while (scanner.hasNext()) {
            String word = scanner.next();
            word = word.replaceAll("[^a-zA-Z ]", "").toLowerCase();
            textArray.add(word);
        }

        System.out.println(textArray);

        /* Using hash keys to look for the words in the dictionary
        for (int i = 0; i < textArray.size() - 1; i++) {
            for (int j = 0; j < 7; j++) {
                if (!textArray.get(i).equals(dictionary.get(j))) {
                    wordCounter++;
                }
            }

            if (wordCounter == 7) {
                unused = unused + textArray.get(i) + " ";
            }

            wordCounter = 0;
        }

        System.out.println(unused);
        */

        // using Binary Search to look through the dictionary
        for (int i = 0; i < textArray.size() - 1; i++) {
            if (search(dictionary, 0, 7, textArray.get(i)) == -1) {
                missing++;
                unused = unused + textArray.get(i) + " ";
            }
        }

        System.out.println(missing + " words missing");
        System.out.println("Words missing: " + unused);

    }

    public static int search(StringTable textText, int first, int size, String target) {
        int middle;

        if (size <= 0) {
            return -1;
        }
        else {
            middle = first + size / 2;
            String midString = textText.get(middle);
            char firstLetter = midString.charAt(0);
            int midValue = (int) firstLetter;
            char targetLetter = target.charAt(0);
            int lTarget = (int) targetLetter;
            if (target.equals(textText.get(middle))) {
                return middle;
            }
            else if (lTarget < midValue) {
                return search(textText, first, size / 2, target);
            }
            else {
                return search(textText, middle + 1, (size - 1) / 2, target);
            }
        }
    }
}