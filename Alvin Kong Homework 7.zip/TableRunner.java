// Alvin Kong   axk1079
// Homework 7 Problem 3

public class TableRunner {
    public static void main (String [] args) {
        Table table = new Table(6);
        table.put(1, "Hi");
        table.put(5, "Bye");
        table.put(11, "See you later");
        table.put(12, "Greetings");
        table.print();
    }
}
