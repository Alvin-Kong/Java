// Alvin Kong   axk1079
// Homework7 Problem 1

import java.util.*;
import java.io.*;

public class Problem1 {
    public static void main(String[ ] args) {
        ArrayList<String> text = new ArrayList<String>();
        ArrayList<String> dict = new ArrayList<String>();
        Scanner scanner;
        Scanner reference;
        int missing = 0;
        String unused = "";

        try {
            scanner = new Scanner(new FileReader("text.txt"));
            reference = new Scanner(new FileReader("dictionary.txt"));
        }
        catch (FileNotFoundException e) {
            System.err.println(e);
            return;
        }

        while (scanner.hasNext()) {
            String tWord = scanner.next();
            tWord = tWord.replaceAll("[^a-zA-Z ]", "").toLowerCase();
            text.add(tWord);
        }

        while (reference.hasNext()) {
            String refWord = reference.next();
            refWord = refWord.replaceAll("[^a-zA-Z ]", "").toLowerCase();
            dict.add(refWord);
        }

        for (int i = 0; i < text.size() - 1; i++) {
            if (search(dict, 0, dict.size(), text.get(i)) == -1) {
                missing++;
                unused = unused + text.get(i) + " ";
            }
        }

        System.out.println(missing + " words missing");
        System.out.println("Words missing: " + unused);
    }

    public static int search(ArrayList<String> textText, int first, int size, String target) {
        int middle;

        if (size <= 0) {
            return -1;
        }
        else {
            middle = first + size / 2;
            String midString = textText.get(middle);
            char firstLetter = midString.charAt(0);
            int midValue = (int) firstLetter;
            char targetLetter = target.charAt(0);
            int lTarget = (int) targetLetter;
            if (target.equals(textText.get(middle))) {
                return middle;
            }
            else if (lTarget < midValue) {
                return search(textText, first, size / 2, target);
            }
            else {
                return search(textText, middle + 1, (size - 1) / 2, target);
            }
        }
    }
}
