//Alvin Kong   Case ID: axk1079
//Homework 10 Problem 2 Part A
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Player {
    protected int[][] playerGrid;
    protected int[][] shipGrid;

    public Player(int[][] setShipGrid) {
        shipGrid = setShipGrid;
        playerGrid = new int[setShipGrid.length][setShipGrid[0].length];
    }

    public int[][] getShips() {
        return shipGrid;
    }

   public void check (int row, int col, int[][] opponentShipGrid) {
     if (opponentShipGrid[row][col] == 1) {
       System.out.println("Hit!");
       playerGrid[row][col] = 1;
    }
     else {
       System.out.println("Miss");
       playerGrid[row][col] = -1;
     }
   }

    public void printGuessed (String description) {
     System.out.println(description);
     System.out.print("  ");
     for (int col = 0; col < playerGrid[0].length; col++) {
      System.out.print(col);
     }
     System.out.println();
     for (int row = 0; row < playerGrid.length; row++) {
       System.out.print(row);
       for (int col = 0; col < playerGrid[0].length; col++) {
         if (playerGrid[row][col] == 1)
           System.out.print("X");
         else if (playerGrid[row][col] == -1)
           System.out.print("O");
         else
           System.out.print(" ");
       }
       System.out.println();
     }
     System.out.println();
   }

   public boolean won(int[][] opponentShipGrid) {
     for (int row = 0; row < opponentShipGrid.length; row++) {
       for (int col = 0; col < opponentShipGrid[0].length; col++) {
         if (playerGrid[row][col] != 1 && opponentShipGrid[row][col] == 1) {
           return false;
         }
       }
     }
     return true;
   }

    public void save(String fileName) throws IOException {
        PrintWriter fileReader = new PrintWriter(fileName);
        String fileText = "";
        for (int row = 0; row < playerGrid.length; row++) {
            for (int col = 0; col < playerGrid[row].length; col++) {
                fileText = fileText + playerGrid[row][col] + " ";
            }
        }
        for (int row = 0; row < shipGrid.length; row++) {
            for (int col = 0; col < shipGrid[row].length; col++) {
                fileText = fileText + playerGrid[row][col] + " ";
            }
        }
        fileReader.print(fileText);
        fileReader.close();
    }

    public void read(String fileName) throws IOException {
        Scanner scan = new Scanner(new File(fileName));
        int [][] combinedGrid = new int [8][4];
        String inFileText = scan.next();
        StringTokenizer space = new StringTokenizer(inFileText," ");
        while (space.hasMoreTokens()) {
            for (int row = 0; row < combinedGrid.length; row++) {
                for (int col = 0; col < combinedGrid[row].length; col++) {
                    String intergerString = space.nextToken();
                    int interger = Integer.parseInt(intergerString);
                    combinedGrid[row][col] = interger;
                }
            }
        }
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 4; col++) {
              if (row < 4) {
                    playerGrid[row][col] = combinedGrid[row][col];
              }
              else {
                    shipGrid[(row - 4)][col] = combinedGrid[row][col];
              }
            }
        }
    }
}

