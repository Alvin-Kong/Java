// Alvin Kong   Case ID: axk1079
// Homework 10 Problem 2
import java.util.Random;
public class AI extends Player {
  Random random = new Random();
  public AI (int[][] shipGrid) {
    super(shipGrid);
  }
  
  public void play (Human human) {
    int[][] humanGrid = human.getShips();
    int row = random.nextInt(humanGrid.length);
    int col = random.nextInt(humanGrid[0].length);
    System.out.println("AI checking (" + row + ", " + col + ")");
    check(row, col, human.getShips());
  }
}