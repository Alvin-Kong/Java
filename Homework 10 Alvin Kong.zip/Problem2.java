// Alvin Kong   Case ID: axk1079
// Homework 10 Problem 2 Part B
import java.io.*;
import java.util.Scanner;
public class Problem2 {
  public static void main (String [] args) {
    Scanner scan = new Scanner(System.in);
    int command = 1;
    int[][] humanShipGrid = {{0,0,0,0,0},
                                             {0,1,0,0,0},
                                             {0,1,0,1,1},
                                             {0,1,0,0,0}};
    int[][] aiShipGrid = {{0,0,0,1,0},
                                    {1,1,0,1,0},
                                    {0,0,0,1,0},
                                    {0,0,0,0,0}};
    Human human = new Human(humanShipGrid);
    AI ai = new AI(aiShipGrid);
    ai.printGuessed("AI");
    human.printGuessed("Human");
    while (command != 0 && !human.won(aiShipGrid) && !ai.won(humanShipGrid)) {
       System.out.println("0 = quit, 1 = play, 2 = save, 3 = read");
       command = scan.nextInt();
       switch (command) {
         case 0: break;
         case 1: human.play(ai);
                     if (human.won(aiShipGrid)) {
                       System.out.println("Human won!");
                     }
                     else {
                       ai.play(human);
                       if (ai.won(humanShipGrid)) {
                         System.out.println("AI won!");
                       }
                       else {
                         ai.printGuessed("AI");
                         human.printGuessed("Human");
                       }
                     }
                   break;
      case 2: try {
                     human.save("human.txt");
                     ai.save("ai.txt");
                    }
                    catch (IOException exception) {
                       System.out.println("Error writing to file. Data not saved.");
                    }
                    break;
      case 3: try {
                     human.read("human.txt"); 
                     ai.read("ai.txt");
                   }
                   catch (IOException exception) {
                     System.out.println("Error reading from file. Data not loaded.");
                   }
                   break;
       }
    }
  }
}    