// Alvin Kong   Case ID: axk1079
// Homework 10 Problem 1
public class Candidate implements Comparable<Candidate> {
  private String name = "Bob";
  private int votes = 0;
  public Candidate(String setName) {
    name = setName;
  }
  
  public void addVotes() {
    votes++;
  }
  
  public String toString() {
    return name + ", " + votes;
  }
  
  public int getCount() {
    return votes;
  }
  
  public int compareTo(Candidate userName) {
    int compareVote = userName.getCount();
    return votes - compareVote;
  }
}