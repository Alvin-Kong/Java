import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextInputDialog;
import java.io.File;
import java.io.PrintWriter;
import java.io.IOException;

public class Problem1Revised extends Application {
    private ChoiceBox<String> choice;
    private Candidate[] candidates;
    private Button voteButton, saveButton;
    private String[] names = {"Big Bird", "Oscar", "Cookie Monster", "Elmo"};

    public void start(Stage primaryStage) {
        candidates = new Candidate[names.length];
        for (int i = 0; i < names.length; i++) {
          candidates[i] = new Candidate(names[i]);
        }
        Label label = new Label("Select a candidate:");
        choice = new ChoiceBox<String>();
        choice.getItems().addAll(names);
        choice.getSelectionModel().selectFirst();
        voteButton = new Button("Vote");
        saveButton = new Button("Save");
        HBox buttons = new HBox(choice, voteButton, saveButton);
        buttons.setSpacing(10);
        voteButton.setOnAction(this::voteButtonPush);
        saveButton.setOnAction(this::saveButtonPush);
        VBox root = new VBox(label, buttons);
        root.setPadding(new Insets(15, 15, 15, 25));
        root.setSpacing(10);
        root.setStyle("-fx-background-color: skyblue");
        
        Scene scene = new Scene(root, 300, 200);
        
        primaryStage.setTitle("Problem1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public void voteButtonPush(ActionEvent event) {
        candidates[choice.getSelectionModel().getSelectedIndex()].addVotes();
    }

    public void saveButtonPush(ActionEvent event) {
      Sorting<Candidate> sort = new Sorting<Candidate>();
      sort.selectionSort(candidates);
      TextInputDialog inputDialog = new TextInputDialog();
      inputDialog.setHeaderText(null);
      inputDialog.setTitle(null);
      inputDialog.setContentText("Enter a file name:");
      Optional<String> fileNameString = inputDialog.showAndWait();
      String fileName = fileNameString.get();
      try {
        PrintWriter fileReader = new PrintWriter(fileName);
        for (int i = 0; i < candidates.length; i++) {
          fileReader.print(candidates[i]);
        }
        fileReader.close();
        Alert confirmDialog = new Alert(AlertType.CONFIRMATION);
        confirmDialog.setHeaderText("Message");
        confirmDialog.setContentText("Data Saved");
        Optional<ButtonType> another = confirmDialog.showAndWait();
      }
      catch (Exception error) {
        Alert confirmDialog = new Alert(AlertType.CONFIRMATION);
        confirmDialog.setHeaderText("Error");
        confirmDialog.setContentText("Error writing to file. Data not saved.");
        confirmDialog.showAndWait();
        Optional<ButtonType> another = confirmDialog.showAndWait();
      }
    }  
    
    public static void main(String[] args){
        launch(args);
    }
}