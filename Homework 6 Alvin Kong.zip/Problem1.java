// Alvin Kong   Case ID: axk1079
// Homework6 Problem 1c
public class Problem1 {
 public static void main(String[] args) {
  Player player1 = new Player("Ace", 10, 50);
  System.out.println("Player 1: " + player1);
  Player player2 = new Player("Crusher", 8, 85);
  System.out.println("Player 2: " + player2);
  System.out.println("Total years: " + player2.getTotalYears());
  if (player1.equals(player2)) {
    System.out.println("Players 1 and 2 are the same.");
  }
  else {
    System.out.println("Players 1 and 2 are not the same.");
  }
  Player player3 = new Player("Crusher", 8, 85);
   System.out.println("Player 3: " + player3);
   if (player2.equals(player3)) {
     System.out.println("Players 2 and 3 are the same.");
   }
   else {
     System.out.println("Players 2 and 3 are not the same.");
   }
  System.out.println("Total years: " + player3.getTotalYears());
 }
}