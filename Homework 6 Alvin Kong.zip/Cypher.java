// Alvin Kong   Case ID: axk1079
// Homeowork 6 Problem 2c
public class Cypher {
  private int multiplier;
  private int subtractor;
  public Cypher (int setMultiplier, int setSubtractor) {
    multiplier = setMultiplier;
    subtractor = setSubtractor;
  }
  
  /* encryption algorithm: multiply the ASCII code by a multiplier and then *
   * subtract that number by a subtractor to obtain the new ASCII code.      *
   * Example: multiplier = 2, subtractor = 4                                                    *
   *                  message: hello                                                               *
   *                  encryption: �����                                                                 */
  public String encrypt (String message) {
    String encryption = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageEChar = message.charAt(letter);
      encryption += (char) ((messageEChar * multiplier) - subtractor);
    }
    return "Encryption: " + encryption;
  }
  
  public String decrypt (String message) {
    String decryption = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageDChar = message.charAt(letter);
      decryption += (char) ((messageDChar + subtractor) / multiplier);
    }
    return "Decryption: " + decryption;
  }
      
  public String printCodes (String message) {
    String code = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageCChar = message.charAt(letter);
      code += (int) (messageCChar) + " ";
    }
    return "Character code: " + code;
  }
}
    