// Alvin Kong   Case ID: axk1079
// Homework 6 Problem 3b
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Problem3 extends Application {
  private ImageView imageView;
    
  Region tele1 = new Region(0, 0, 100);
  Region tele2 = new Region(500, 500, 100);
  Region alienRegion = new Region(200, 200, 100);
    
  public void start(Stage primaryStage) {
    Image alien = new Image("alien.png");
    imageView = new ImageView(alien);
    imageView.setX(200);
    imageView.setY(200);
    
    Rectangle teleRect1 = new Rectangle(tele1.getPosX(), tele1.getPosY(), tele1.getSize(), tele1.getSize());
    teleRect1.setFill(Color.BLACK);
    Rectangle teleRect2 = new Rectangle(tele2.getPosX(), tele2.getPosY(), tele2.getSize(), tele2.getSize());
    teleRect2.setFill(Color.BLACK);
    
    Group root = new Group(imageView, teleRect1, teleRect2);
    Scene scene = new Scene(root, 600, 600);
    scene.setOnKeyPressed(this::processKeyPress);
    primaryStage.setTitle("Alien Teleportation");
    primaryStage.setScene(scene);
    primaryStage.show();
  }

  public void processKeyPress(KeyEvent event){
    switch (event.getCode()) {
      case UP:
        alienRegion.move(0, -10);
        alienRegion.moveImageViewToRegion(imageView, alienRegion);
        break;
      case DOWN:
        alienRegion.move(0, 10);
        alienRegion.moveImageViewToRegion(imageView, alienRegion);
        break;
      case RIGHT:
       alienRegion.move(10, 0);
       alienRegion.moveImageViewToRegion(imageView, alienRegion);
         break;
      case LEFT:
        alienRegion.move(-10, 0);
        alienRegion.moveImageViewToRegion(imageView, alienRegion);
         break;
      default:
         break;
    }
    if (alienRegion.inRegion(tele1)) {
      alienRegion.move(500, 500);
      alienRegion.moveImageViewToRegion(imageView, tele2);
    }
    if (alienRegion.inRegion(tele2)) {
      alienRegion.move(-500, -500);
      alienRegion.moveImageViewToRegion(imageView, tele1);
    }
  }
    
  public static void main(String[] args) {
    launch(args);
  }
}