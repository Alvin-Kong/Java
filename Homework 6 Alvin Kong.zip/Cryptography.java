// Alvin Kong   Case ID: axk1079
// Homework 6 Problem 1a
public interface Cryptography {
  public String encrypt (String message);
  public String decrypt (String message);
  public String printCodes (String message);
}