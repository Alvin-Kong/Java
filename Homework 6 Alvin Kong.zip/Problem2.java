// Alvin Kong   Case ID: axk1079
// Homework 6 Problem 2d
import java.util.Scanner;
public class Problem2 {
 public static void main(String[] args) {
   Scanner scan = new Scanner(System.in);
   System.out.println("Encrypt or decrypt?");
   String userTask = scan.nextLine();
   System.out.println("Caesar or custom?");
   String userMethod = scan.nextLine();
   System.out.println("Enter message: ");
   String message = scan.nextLine();
   if (userTask.equals("encrypt")) {
     if (userMethod.equals("caesar")) {
       Caesar caesar = new Caesar(3);
       System.out.println(caesar.printCodes(message));
       System.out.println(caesar.encrypt(message));
     }
     if (userMethod.equals("custom")) {
       Cypher cypher = new Cypher(2, 4);
       System.out.println(cypher.printCodes(message));
       System.out.println(cypher.encrypt(message));
     }
   }
   if (userTask.equals("decrypt")) {
     if (userMethod.equals("caesar")) {
       Caesar caesar = new Caesar(3);
       System.out.println(caesar.printCodes(message));
       String decryption = caesar.decrypt(message);
       System.out.println(decryption);
     }
     if (userMethod.equals("custom")) {
       Cypher cypher = new Cypher(2, 4);
       System.out.println(cypher.printCodes(message));
       System.out.println(cypher.decrypt(message));
     }
   }
 }
}
