// Alvin Kong   Case ID: axk1079
// Homework 6 Problem 1a
public class Statistics {
  private int years;
  private int points;
  public Statistics(int setYears, int setPoints) {
    years = setYears;
    points = setPoints;
  }
  
  public int getYears() {
    return years;
  }
  
  public int getPoints() {
    return points;
  }
  
  public boolean equals(Statistics stats) {
    if (years == stats.getYears() && points == stats.getPoints()) {
      return true;
    }
    else {
      return false;
    }
  }
  
  public String toString() {
    return years + ", " + points;
  }
}