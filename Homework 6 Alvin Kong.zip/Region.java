// Alvin Kong   Case ID: axk1079
// Homework 6 Problem 3a
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
public class Region {
  private int posX;
  private int posY;
  private int size;
  public Region (int setX, int setY, int setSize) {
    posX = setX;
    posY = setY;
    size = setSize;
  }
  
  public double getPosX() {
    return posX;
  }
  
  public double getPosY() {
    return posY;
  }
  
  public double getSize() {
    return size;
  }
  
  public void move ( int moveX, int moveY) {
    posX = posX + moveX;
    posY = posY + moveY;
  }
  
  public void moveImageViewToRegion (ImageView imageView, Region region) {
    imageView.setX(region.getPosX());
    imageView.setY(region.getPosY());
  }
  
  public boolean inRegion (Region teleRegion) {
    boolean isInRegion = false;
    if (posX == teleRegion.getPosX() && posY == teleRegion.getPosY()) {
      return true;
    }
    return isInRegion;
  }
}