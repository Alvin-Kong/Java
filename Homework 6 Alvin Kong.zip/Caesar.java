// Alvin Kong   Case ID: axk1079
// Homework 6 Problem 2b
public class Caesar implements Cryptography {
  private int shift;
  public Caesar (int setShift) {
    shift = setShift;
  }
  
  public String encrypt (String message) {
    String encryption = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageEChar = message.charAt(letter);
      encryption += (char) (messageEChar + shift);
    }
    return "Encryption: " + encryption;
  }
  
  public String decrypt (String message) {
    String decryption = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageDChar = message.charAt(letter);
      decryption += (char) (messageDChar - shift);
    }
    return "Decryption: " + decryption;
  }
      
  public String printCodes (String message) {
    String code = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageCChar = message.charAt(letter);
      code += (int) (messageCChar) + " ";
    }
    return "Character code: " + code;
  }
}
    