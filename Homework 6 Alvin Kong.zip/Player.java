// Alvin Kong   Case ID: axk1079
// Homework 6 Problem 1b
public class Player {
  private String name;
  private Statistics stats;
  private static int totalYears;
  public Player(String setName, int setYears, int setPoints) {
    name = setName;
    stats = new Statistics(setYears, setPoints);
    totalYears = totalYears + setYears;
  }
  
  public String getName() {
    return name;
  }
  
  public Statistics getStatistics() {
    return stats;
  }
  
  public static int getTotalYears() {
    return totalYears;
  }
  
  public boolean equals(Player player) {
    if (name.equals(player.getName()) && stats.equals(player.getStatistics())) {
      return true;
    }
    else {
      return false;
    }
  }
  
  public String toString() {
    return name + ", " + stats;
  }
}