// Alvin Kong   axk1079
// Homework 9 Problem 4

public class GraphDemo {
	public static void main(String[ ] args) {
		// Build a graph
		Graph g = new Graph(4);
		g.addEdge(0, 1);
		g.addEdge(1, 2);
		g.addEdge(2, 3);
		g.addEdge(3, 0);
		g.addEdge(0, 3);
		g.addEdge(1, 3);
		g.addEdge(2, 2);

		g.setLabel(0, "Home");
		g.setLabel(1, "1st base");
		g.setLabel(2, "2nd base");
		g.setLabel(3, "3rd base");

		g.hubs();
	}
}


