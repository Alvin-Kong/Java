// Alvin Kong   axk1079
// Homework 9 Problem 3

/******************************************************************************
 * A <CODE>Graph</CODE> is a labeled graph with a fixed number of vertices.
 *
 * <b>Java Source Code for this class:</b>
 *   <A HREF="../../../../edu/colorado/collections/Graph.java">
 *   http://www.cs.colorado.edu/~main/EDU/colorado/collections/Graph.java
 *   </A>
 *
 * @author Michael Main
 *   <A HREF="mailto:main@colorado.edu"> (main@colorado.edu) </A>
 *
 * @version Feb 10, 2016
 ******************************************************************************/
public class WeightedGraph implements Cloneable {
    // Invariant of the Graph class:
    //   1. The vertex numbers range from 0 to labels.length-1.
    //   2. For each vertex number i, labels[i] contains the label for vertex i.
    //   3. For any two vertices i and j, edges[i][j] is true if there is a
    //      vertex from i to j; otherwise edges[i][j] is false.
    private int[ ][ ] edges;
    private Object[ ] labels;


    /**
     * Initialize a <CODE>Graph</CODE> with <CODE>n</CODE> vertices,
     * no edges, and null labels.
     * @param n
     *   the number of vertices for this <CODE>Graph</CODE>
     * <b>Precondition:</b>
     *   <CODE>n</CODE> is nonnegative.
     * <b>Postcondition:</b>
     *   This <CODE>Graph</CODE> has <CODE>n</CODE> vertices, numbered
     *   <CODE>0</CODE> to <CODE>n-1</CODE>. It has no edges and all
     *   vertex labels are null.
     * @exception OutOfMemoryError
     *   Indicates insufficient memory for the specified number of nodes.
     * @exception NegativeArraySizeException
     *   Indicates that <CODE>n</CODE> is negative.
     **/
    public WeightedGraph(int n) {
        edges = new int[n][n];      // All values initially -1
            for (int i = 0; i < n - 1 ; i++) {
                for (int j = 0; j < n -1; j++) {
                    edges[i][j] = -1;
                }
            }
        labels = new Object[n];     // All values initially null
    }

    /**
     * Add a new edge to this <CODE>Graph</CODE>.
     * @param source
     *   the vertex number of the source of the new edge
     * @param target
     *   the vertex number of the target of the new edge
     * <b>Precondition:</b>
     *   Both <CODE>source</CODE> and <CODE>target</CODE> are nonnegative and
     *   less than <CODE>size()</CODE>.
     * <b>Postcondition:</b>
     *   This <CODE>Graph</CODE> has all the edges that it originally had plus
     *   another edge from the specified <CODE>source</CODE> to the specified
     *   <CODE>target</CODE>. (If the edge was already present, then this
     *   <CODE>Graph</CODE> is unchanged.)
     * @exception ArrayIndexOutOfBoundsException
     *   Indicates that the <CODE>source</CODE> or <CODE>target</CODE> was not a
     *   valid vertex number.
     **/
    public void addEdge(int source, int target, int weight) {
        edges[source][target] = weight;
    }

    /**
     * Generate a copy of this <CODE>Graph</CODE>.
     * @return
     *   The return value is a copy of this <CODE>Graph</CODE>. Subsequent changes to the
     *   copy will not affect the original, nor vice versa. Note that the return
     *   value must be type cast to a <CODE>Graph</CODE> before it can be used.
     * @throws OutOfMemoryError
     *   Indicates insufficient memory for creating the clone.
     **/
    public Object clone( ) {  // Clone a Graph object.
        WeightedGraph answer;

        try
        {
            answer = (WeightedGraph) super.clone( );
        }
        catch (CloneNotSupportedException e)
        {  // This would indicate an internal error in the Java runtime system
            // because super.clone always works for an Object.
            throw new InternalError(e.toString( ));
        }

        answer.edges = (int [ ][ ]) edges.clone( );
        answer.labels = (Object [ ]) labels.clone( );

        return answer;
    }

    /**
     * Accessor method to get the label of a vertex of this <CODE>Graph</CODE>.
     * @param vertex
     *   a vertex number
     * <b>Precondition:</b>
     *   <CODE>vertex</CODE> is nonnegative and
     *   less than <CODE>size()</CODE>.
     * @return
     *   the label of the specified vertex in this <CODE>Graph</CODE>
     * @exception ArrayIndexOutOfBoundsException
     *   Indicates that the <CODE>vertex</CODE> was not a
     *   valid vertex number.
     **/
    public Object getLabel(int vertex) {
        return labels[vertex];
    }

    /**
     * Modification method to change the label of a vertex of this <CODE>Graph</CODE>.
     * @param vertex
     *   a vertex number
     * @param newLabel
     *   a new label (which may be null)
     * <b>Precondition:</b>
     *   <CODE>vertex</CODE> is nonnegative and
     *   less than <CODE>size()</CODE>.
     * <b>Postcondition:</b>
     *   The label of the specified vertex in this <CODE>Graph</CODE> has been
     *   changed to the <CODE>newLabel</CODE>.
     * @exception IndexOutOfBoundsException
     *   Indicates that the <CODE>vertex</CODE> was not a
     *   valid vertex number.
     **/
    public void setLabel(int vertex, Object newLabel) {
        labels[vertex] = newLabel;
    }


    /**
     * Determine the number of vertices in this <CODE>Graph</CODE>.
     * @return
     *   the number of vertices in this <CODE>Graph</CODE>
     **/
    public int size( ) {
        return labels.length;
    }

    public int getWeight(int source, int target) {
        return edges[source][target];
    }

    public int printTotalPath(int[] path){
        int total = 0;
        boolean valid = true;
        for (int i = 0; i < path.length - 1; i++) {
            if (edges[path[i]][path[i + 1]] != -1) {
                total = total + edges[path[i]][path[i + 1]];
            }
            else {
                valid = false;
            }
        }

        if (valid) {
            return total;
        }
        else {
            return -1;
        }
    }

    public static void main(String[ ] args) {
        WeightedGraph g = new WeightedGraph(4);
        g.addEdge(0, 1, 4);
        g.addEdge(1, 2, 3);
        g.addEdge(2, 3, 1);
        g.addEdge(3, 0, 5);

        g.setLabel(0, "Home");
        g.setLabel(1, "1st base");
        g.setLabel(2, "2nd base");
        g.setLabel(3, "3rd base");

        int[] validPath = {0, 1, 2, 3, 0};
        int[] invalidPath = {2, 1, 3, 0};

        if (g.printTotalPath(validPath) != -1) {
            System.out.println("Path total: " + g.printTotalPath(validPath));
        }
        else {
            System.out.println("Path is invalid");
        }

        if (g.printTotalPath(invalidPath) != -1) {
            System.out.println("Path total: " + g.printTotalPath(invalidPath));
        }
        else {
            System.out.println("Path is invalid");
        }
    }
}



