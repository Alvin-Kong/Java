// Alvin Kong   axk1079
// Homework 9 Problem 1
public class HeapSort {
    private int[] data = new int[10]; // Heap data
    private int manyItems = 0; // Quantity of items in the heap

    public int removeMax() {
        if (manyItems == 0)
            throw new RuntimeException();
        int maxValue = data[0]; // Get root value
        manyItems--;
        data[0] = data[manyItems]; // Copy item at end of heap to the root
        // Move root to correct level
        int iParent = 0; // Index of parent initialized to the root
        int iChild = iParent * 2 + 1; // Index of child initialized to the left child of the root
        boolean done = false; // Flag to indicate when all children are less
        while (iChild < manyItems && !done) { // While there is at least 1 child, and not done...
            int maxChild = data[iChild]; // Initialize max child value to be that of left child
            if (iChild + 1 < manyItems) { // If there is another node, then it's the right child
                if (data[iChild + 1] > maxChild) {
                    iChild++; // Move child index to right child
                    maxChild = data[iChild];
                }
            }
            if (data[iParent] < maxChild) {
                // Swap
                int temp = data[iParent];
                data[iParent] = data[iChild];
                data[iChild] = temp;
                // Setup for checking next level
                iParent = iChild;
                iChild = iParent * 2 + 1;
            }
            else
                done = true; // No children are greater, so we're done
        }
        return maxValue;
    }

    public void add(int element) {
        if (manyItems == data.length)
            ensureCapacity((manyItems + 1) * 2);
        data[manyItems] = element;
        manyItems++;
        int iChild = manyItems - 1; // Index of child initialized to element at end
        int iParent = (iChild - 1) / 2; // Index of parent to be compared
        // Move new value to correct level
        while (iChild >= 0 && data[iParent] < data[iChild]) {
            // Swap
            int temp = data[iParent];
            data[iParent] = data[iChild];
            data[iChild] = temp;
            iChild = iParent;
            iParent = (iChild - 1) / 2;
        }
    }

    // Print all heap values with array indexes
    public void print() {
        for (int i = 0; i < manyItems; i++)
            System.out.println("[" + i + "] " + data[i]);
    }

    // Taken from ArrayBag.java
    public void ensureCapacity(int minimumCapacity) {
        int[] biggerArray;

        if (data.length < minimumCapacity) {
            biggerArray = new int[minimumCapacity];
            System.arraycopy(data, 0, biggerArray, 0, manyItems);
            data = biggerArray;
        }
    }

    public static void main(String[] args) {
        HeapSort h = new HeapSort();
        int[] unsorted = {2, 6, 7, 3, 9, 4, 1, 5, 8};
        int [] sorted = new int[10];
        for (int i = 0; i < unsorted.length; i++) {
            h.add(unsorted[i]);
        }

        h.print();
        System.out.println("****************");

        for (int j = 0; j < unsorted.length; j++) {
            sorted[j] = h.removeMax();
            h.print();
            System.out.println("****************");
        }

        for (int k = sorted.length - 1; k >= 0; k--) {
            System.out.print(sorted[k] + "  ");
        }
    }
}
