// Alvin Kong   Case ID: axk1079
// Homeowrk 8 Problem 2a
public class Player {
   protected int[][] shipGrid;      
   protected int[][] playerGrid;
   public Player (int[][] setShipGrid) {
     shipGrid = setShipGrid;
     playerGrid = new int[shipGrid.length][shipGrid[0].length];
   }
   
   public int[][] getShips() {
     return shipGrid;
   }
   
   public void check (int row, int col, int[][] opponentShipGrid) {
     if (opponentShipGrid[row][col] == 1) {
       System.out.println("Hit!");
       playerGrid[row][col] = 1;
    }
     else {
       System.out.println("Miss");
       playerGrid[row][col] = -1;
     }
   }
    
   public void printGuessed (String description) {
     System.out.println(description);
     System.out.print("  ");
     for (int col = 0; col < playerGrid[0].length; col++) {
      System.out.print(col);
     }
     System.out.println();
     for (int row = 0; row < playerGrid.length; row++) {
       System.out.print(row);
       for (int col = 0; col < playerGrid[0].length; col++) {
         if (playerGrid[row][col] == 1)
           System.out.print("X");
         else if (playerGrid[row][col] == -1)
           System.out.print("O");
         else
           System.out.print(" ");
       }
       System.out.println();
     }
     System.out.println();
   }

   public boolean won(int[][] opponentShipGrid) {
     for (int row = 0; row < opponentShipGrid.length; row++) {
       for (int col = 0; col < opponentShipGrid[0].length; col++) {
         if (playerGrid[row][col] != 1 && opponentShipGrid[row][col] == 1) {
           return false;
         }
       }
     }
     return true;
   }
}