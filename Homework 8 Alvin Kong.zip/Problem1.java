// Alvin Kong   Case ID: axk1079
// Homework 8 Problem 1d
import java.util.Scanner;
public class Problem1 {
  public static void main (String [] args) {
    Scanner scan = new Scanner(System.in);
    System.out.print("Encrypt or decrypt? ");
    String command = scan.nextLine();
    System.out.print("Enter message");
    String message = scan.nextLine();
    
    Algorithm algorithm = new Algorithm("Caesar algorithm");
    Caesar caesar = new Caesar(3);
    algorithm.printCodes(message);
    
    if (command.equals("encrypt")) {
      String encryption = caesar.encrypt(message);
      System.out.println(encryption);
    }
    else {
      String decryption = caesar.decrypt(message);
      System.out.println(decryption);
    }
  }
}