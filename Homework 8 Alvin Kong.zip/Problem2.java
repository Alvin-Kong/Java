// Alvin Kong   Case ID: axk1079
// Homework 8 Problem 2d
import java.util.Scanner;
public class Problem2 {
  public static void main (String [] args) {
    Scanner scan = new Scanner(System.in);
    int[][] humanShipGrid = {{0,0,0,0,0},
                                             {0,1,0,0,0},
                                             {0,1,0,1,1},
                                             {0,1,0,0,0}};
    int[][] aiShipGrid = {{0,0,0,1,0},
                                    {1,1,0,1,0},
                                    {0,0,0,1,0},
                                    {0,0,0,0,0}};
    Human human = new Human(humanShipGrid);
    AI ai = new AI(aiShipGrid);
   
    ai.printGuessed("AI");
    human.printGuessed("Human");
    System.out.println("Play (1=yes, 0=no)? ");
    int command = scan.nextInt();
    while (command == 1 && !human.won(aiShipGrid) && !ai.won(humanShipGrid)) {
      human.play(ai);
      if (human.won(aiShipGrid)) {
        System.out.println("Human won!");
      }
      else {
        ai.play(human);
        if (ai.won(humanShipGrid)) {
          System.out.println("AI won!");
        }
        else {
          ai.printGuessed("AI");
          human.printGuessed("Human");
          System.out.println("Play (1=yes, 0=no)? ");
          command = scan.nextInt();
        }
      }
    }
  }
}    