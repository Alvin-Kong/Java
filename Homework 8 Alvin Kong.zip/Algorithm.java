// Alvin Kong   Case ID: axk1079
// Homework 8 Problem 1b
public class Algorithm implements Cryptography {
  private String name;
  public Algorithm (String setName) {
    name = setName;
  }
  
  public String encrypt (String message) { 
    return message;
  }
  
  public String decrypt (String message) {
    return message;
  }
  
  public void printCodes (String message) {
    String code = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageCChar = message.charAt(letter);
      code += (int) (messageCChar) + " ";
    }
    System.out.println("Character code: " + '\n' + "Using " + name + ": " + code);
  }
}