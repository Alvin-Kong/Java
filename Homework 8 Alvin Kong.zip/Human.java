// Alvin Kong   Case ID: axk1079
// Homework 8 Problem 2b
import java.util.Scanner;
public class Human extends Player {
  Scanner scan = new Scanner(System.in);
  public Human (int[][] shipGrid) {
    super(shipGrid);
  }
  
  public void play (AI ai) {
    System.out.println("Enter row: ");
    int row = scan.nextInt();
    System.out.println("Enter column: ");
    int col = scan.nextInt();
    check(row, col, ai.getShips());
  }
}