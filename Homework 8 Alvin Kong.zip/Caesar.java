// Alvin Kong   Case ID: axk1079
// Homework 8 Problem 1c
public class Caesar extends Algorithm {
  private int shift;
  public Caesar (int setShift) {
    super("Caesar algorithm");
    shift = setShift;
  }
  
  public String encrypt (String message) {
    String encryption = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageEChar = message.charAt(letter);
      encryption += (char) (messageEChar + shift);
    }
    return "Encryption: " + encryption;
  }
  
  public String decrypt (String message) {
    String decryption = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageDChar = message.charAt(letter);
      decryption += (char) (messageDChar - shift);
    }
    return "Decryption: " + decryption;
  }
      
  public void printCodes (String message) {
    String code = "";
    for (int letter = 0; letter < message.length(); letter++) {
      int messageCChar = message.charAt(letter);
      code += (int) (messageCChar) + " ";
    }
    System.out.println("Character code: " + code);
  }
}
    