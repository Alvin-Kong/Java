// Alvin Kong   Case ID: axk1079
// Homework 8 Problem 1a
public interface Cryptography {
  public String encrypt (String message);
  public String decrypt (String message);
  public void printCodes (String message);
}