// Alvin Kong   axk1079
// Homework 10 Problem 1b

public class CoinGame {
    public static void main(String[] args) {
        Graph g = new Graph(8);
        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(0, 3);
        g.addEdge(1, 0);
        g.addEdge(1, 4);
        g.addEdge(2, 0);
        g.addEdge(3, 0);
        g.addEdge(3, 6);
        g.addEdge(4, 1);
        g.addEdge(4, 7);
        g.addEdge(5, 7);
        g.addEdge(6, 3);
        g.addEdge(6, 7);
        g.addEdge(7, 4);
        g.addEdge(7, 5);
        g.addEdge(7, 6);

        g.setLabel(0, "HHH");
        g.setLabel(1, "THH");
        g.setLabel(2, "HTH");
        g.setLabel(3, "HHT");
        g.setLabel(4, "TTH");
        g.setLabel(5, "THT");
        g.setLabel(6, "HTT");
        g.setLabel(7, "TTT");

        g.breadthFirstSearch(g, 2, 5);
    }
}