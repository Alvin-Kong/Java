// Alvin Kong   axk1079
// Homework 10 Problem 3

public class DijkstraGraph implements Cloneable {
    private double[ ][ ] edges;
    private Object[ ] labels;

    public DijkstraGraph(int n) {
        edges = new double[n][n];  // Edge weights (-1 means no connection)
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                if (i == j)
                    edges[i][j] = 0; // Can stay in place with nothing extra
                else
                    edges[i][j] = -1; // Negative indicates no connection
        labels = new Object[n];     // All values initially null
    }

    public double getWeight(int source, int target)
    {
        return edges[source][target];
    }

    public void addEdge(int source, int target, double weight)
    {
        edges[source][target] = weight;
    }

    public Object getLabel(int vertex)
    {
        return labels[vertex];
    }

    public void setLabel(int vertex, Object newLabel)
    {
        labels[vertex] = newLabel;
    }

    public boolean isEdge(int source, int target)
    {
        return edges[source][target] >= 0;
    }

    public int size( )
    {
        return labels.length;
    }

    public int[ ] neighbors(int vertex) {
        int i;
        int count;
        int[ ] answer;

        // First count how many edges have the vertex as their source
        count = 0;
        for (i = 0; i < labels.length; i++) {
            if (edges[vertex][i] > 0)
                count++;
        }

        // Allocate the array for the answer
        answer = new int[count];

        // Fill the array for the answer
        count = 0;
        for (i = 0; i < labels.length; i++) {
            if (edges[vertex][i] > 0)
                answer[count++] = i;
        }

        return answer;
    }

    // Helper method that checks for valid path
    private boolean checkPath(int[] path) {
        for (int i = 0; i < path.length - 1; i++)
            if (!isEdge(path[i], path[i + 1]))
                return false;
        return true;
    }

    // Helper method that prints labels for given path
    private void printPath(int[] path) {
        System.out.print("The path from ");
        for (int i = 0; i < path.length - 1; i++)
            System.out.print(getLabel(path[i]) + " to ");
        System.out.print(getLabel(path[path.length-1]));
    }

    // Prints total weights for given path, if valid
    public void printTotalPath(int[] path) {
        printPath(path);
        if (!checkPath(path))
            System.out.println(" is not valid.");
        else {
            double total = 0;
            for (int i = 0; i < path.length - 1; i++)
                total += getWeight(path[i], path[i + 1]);
            System.out.println(" has a total of " + total + ".");
        }
    }

    public int shortestPath(int start, int target) {
        int [] distance = new int [labels.length];
        boolean [] allowed = new boolean [labels.length];
        int vertex = start;

        for (int i = 0; i < labels.length - 1; i++) {
            if (i == start) {
                distance[i] = 0;
            }
            else {
                distance[i] = -1;
            }
        }

        for (int allowedSize = 1; allowedSize < labels.length; allowedSize++) {
            int [] connections = neighbors(vertex);
            int next = vertex;
            int sum;

            if (connections.length > 1) {
                for (int j = 0; j < connections.length - 1; j++) {
                    if (!allowed[connections[j]]) {
                        int compare = connections[j];
                        allowed[compare] = true;
                        if (next == vertex || getWeight(vertex, next) > getWeight(vertex, compare)) {
                            next = compare;
                        }
                    }
                }
            }
            else if (connections.length == 1 && !allowed[connections[0]]) {
                next = connections[0];
                allowed[connections[0]] = true;
            }

            for (int v = 0; v < labels.length; v++) {
                if (!allowed[v] && isEdge(next, v)) {
                    sum = distance[v] + getWeight(next, v);
                    if (sum < distance[v]) {
                        distance[v] = sum;
                    }
                }
            }
        }
        return -1;
    }


    public static void main(String[ ] args) {
        DijkstraGraph g = new DijkstraGraph(6);
        g.addEdge(0, 1, 2);
        g.addEdge(0, 5, 9);
        g.addEdge(1, 2, 8);
        g.addEdge(1, 3, 15);
        g.addEdge(1, 5, 6);
        g.addEdge(2, 3, 1);
        g.addEdge(4, 2, 7);
        g.addEdge(4, 3, 3);
        g.addEdge(5, 4, 3);
        g.setLabel(0, "V0");
        g.setLabel(1, "V1");
        g.setLabel(2, "V2");
        g.setLabel(3, "V3");
        g.setLabel(4, "V4");
        g.setLabel(5, "V5");

        g.shortestPath(0, 3);
    }

}

