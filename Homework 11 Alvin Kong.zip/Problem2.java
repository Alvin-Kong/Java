// Alvin Kong   axk1079
// Homework 11 Problem 2
public class Problem2 {
   public static void main(String[] args)
   {
      Maze2 labyrinth = new Maze2();
      if (labyrinth.traverse(0, 0)) {
         System.out.println("\nThe maze was successfully traversed!");
      }
      else {
         System.out.println("There is no possible path.");
      }
      System.out.println(labyrinth);
   }
}
