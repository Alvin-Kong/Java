// Alvin Kong   axk1079
// Homework 11 Problem 3
public class Problem3 {
   public static void main(String[] args)
   {
      Maze3 labyrinth = new Maze3();
      if (labyrinth.traverse(0, 0)) {
         System.out.println("\nThe maze was successfully traversed!");
      }
      else {
         System.out.println("There is no possible path.");
      }
      System.out.println(labyrinth);
   }
}
