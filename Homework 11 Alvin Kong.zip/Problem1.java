// Alvin Kong   axk1079
// Homework 11 Problem 1
public class Problem1 {
  public static void max(int[] nums, int startIndex, int stopIndex) {
    int mid = (startIndex + stopIndex) / 2;
    int maxNum1 = nums[startIndex];
    int maxNum2 = nums[mid];
    if (startIndex == stopIndex) {
      System.out.println("The maximum is " + nums[startIndex]);
    }
    else {
      for (int i = startIndex; i < mid + 1; i++) {
        if (nums[i] > maxNum1) {
          maxNum1 = nums[i];
        }
      }
      System.out.println("maxNum1 = " + maxNum1);
      for (int i = mid; i < stopIndex + 1; i++) {
        if (nums[i] > maxNum2) {
          maxNum2 = nums[i];
        }
      }
      System.out.println("maxNum2 = " + maxNum2);
      if (maxNum1 >= maxNum2) {
        System.out.println(maxNum1);
        max(nums, startIndex, mid);
      }
      else {
        System.out.println(maxNum2);
        max(nums, mid + 1, stopIndex);
      }
    }
  }

  public static void main(String[] args) {
    int[] nums = {130, 160, 110, 120, 150};
    max(nums, 0, nums.length - 1);
  }
}