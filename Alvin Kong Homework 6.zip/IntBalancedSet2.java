// Alvin Kong   axk1079
// Homework 6 Problem 6

public class IntBalancedSet2
{
   // Invariant of the IntBalancedSet class:
   //   1. The elements of the Set are stored in a B-tree, satisfying the six
   //      B-tree rules.
   //   2. The number of elements in the tree's root is in the instance
   //      variable dataCount, and the number of subtrees of the root is stored
   //      stored in the instance variable childCount.
   //   3. The root's elements are stored in data[0] through data[dataCount-1].
   //   4. If the root has subtrees, then subtree[0] through 
   //      subtree[childCount-1] are references to these subtrees.
   private final int MINIMUM = 1;
   private final int MAXIMUM = 2*MINIMUM;
   int dataCount;
   int[ ] data = new int[MAXIMUM + 1];
   int childCount;
   IntBalancedSet2[ ] subset = new IntBalancedSet2[MAXIMUM + 2]; 

   // Constructor for leaf node (no children)
   public IntBalancedSet2(int[] setData) {
      if (setData.length < MINIMUM || setData.length > MAXIMUM) {
         throw new IllegalArgumentException();
      }

      data = setData;
      dataCount = setData.length;
      childCount = 0;
   }

   // Constructor for non-leaf node (has children)
   public IntBalancedSet2(int[] setData, IntBalancedSet2[ ] setSubset) {
      if (setData.length < MINIMUM || setData.length > MAXIMUM) {
         throw new IllegalArgumentException();
      }

      data = setData;
      dataCount = setData.length;
      subset = setSubset;
      childCount = 1;
   }
   
   public static void main(String[ ] args) {
      int[] data1 = {6};
      int[] data2 = {2,4};
      int[] data3 = {1,3,5};
      int[] data4 = {9};
      int[] data5 = {7,8};
      int[] data6 = {10};
      IntBalancedSet2 set0 = new IntBalancedSet2(data3);
      IntBalancedSet2 set1 = new IntBalancedSet2(data2, set0);
      IntBalancedSet2 set2 = new IntBalancedSet2(data1, set1);
      IntBalancedSet2 set3 = new IntBalancedSet2(data5);
      IntBalancedSet2 set4 = new IntBalancedSet2(data4, set3);
      IntBalancedSet2 set5 = new IntBalancedSet2(data6);
   }

   public boolean isValid() {
      for (int i = 0; i < dataCount - 1; i++) {
         if (lessThan(i) == true && greaterThan(i) == true) {
            return true;
         }
         else {
            return false;
         }
      }
   }

   public boolean lessThan(int parentKey) {
      if (data[parentKey] > data[(parentKey - 1) / 2]) {
         return true;
      }
      else {
         return false;
      }
   }
   
   public boolean greaterThan(int parentKey) {
      if (data[parentKey] < data[(parentKey - 1) / 2]) {
         return false;
      }
      else {
         return true;
      }
   }
   

   // Print a representation of this set's B-tree, useful during debugging.
   public void print(int indent)
   {
      final int EXTRA_INDENTATION = 4;
      int i;
      int space;
  
      // Print the indentation and the data from this node
      for (space = 0; space < indent; space++)
         System.out.print(" ");
      for (i = 0; i < dataCount; i++)
         System.out.print(data[i] + " ");
      System.out.println( );
         
      // Print the subtrees
      for (i = 0; i < childCount; i++)
         subset[i].print(indent + EXTRA_INDENTATION);
   }
}
