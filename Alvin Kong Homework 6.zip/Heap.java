// Alvin Kong   axk1079
// Homework 6 Problem 2

public class Heap {
	private int[] data = new int[10]; // Heap data
	private int manyItems = 0; // Quantity of items in the heap
	
	public int removeMax() {
		if (manyItems == 0)
			throw new RuntimeException();
		int maxValue = data[0]; // Get root value
		manyItems--;
		int out = data[manyItems];
		data[0] = out;
		int i = 0;
		int child;
		while (out < data[(i * 2) + 1] || out < data[(i * 2) + 2]){
			if (out < data[i * 2]){
				child = data[i * 2];
				data[i * 2] = out;
				data[i] = child;
				i = i * 2;
			}
			else if ( out < data[(i * 2) + 1]){
				child = data[(i * 2) + 1];
				data[(i * 2) + 1] = out;
				data[i] = child;
				i = (i * 2) + 1;
			}

		}

		return maxValue;
	}

	public void add(int element) {
		if (manyItems == data.length) {
			ensureCapacity((manyItems + 1) * 2);
		}
		data[manyItems] = element;

		int parent;
		int i = (manyItems - 1) / 2;
		int index = manyItems;

		while (i != 0 && element > data[i]) {
			parent = data[i];
			data[i] = element;
			data[index] = parent;
			i = (i - 1) / 2;
			index = (index - 1) / 2;
		}

		manyItems++;
	}

	// Print all heap values with array indexes
	public void print() {
		for (int i = 0; i < manyItems; i++)
			System.out.println("[" + i + "] " + data[i]);
	}

	// Taken from ArrayBag.java
	public void ensureCapacity(int minimumCapacity) {
		int[] biggerArray;

		if (data.length < minimumCapacity) {
			biggerArray = new int[minimumCapacity];
			System.arraycopy(data, 0, biggerArray, 0, manyItems);
			data = biggerArray;
		}
	}

	public static void main(String[] args) {
		Heap h = new Heap();
		System.out.println("Adding values...");
		h.add(10);
		h.add(15);
		h.add(5);
		h.add(20);
		h.add(12);
		h.print();
		System.out.print("Removing... ");
		System.out.println(h.removeMax());
		h.print();
	}
}
           