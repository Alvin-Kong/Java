// Alvin Kong   Case ID: axk1079
// Homework 5 Problem 3
import java.util.Scanner;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
public class Problem3 extends Application {
  Scanner scan = new Scanner(System.in);
  int userInput;
  int width = 30;
  int height = 30;
  int row = 0;
  public void start(Stage primaryStage) {
    Group root = new Group();
    System.out.println("How many rows?");
    userInput = scan.nextInt();
    for (int i = userInput; i > 0; i--) {
      int x = ((i - 1) * width);
      int y = ((userInput - i) * height);
      row++;
      for (int n = 1; n <= (row * 2) - 1; n++) {
        Rectangle box = new Rectangle(x, y, width, height);
        box.setStroke(Color.WHITE);
        box.setFill(null);
        root.getChildren().add(box);
        x = x + 30;
      }
    }       
    Scene scene = new Scene(root, 600, 400, Color.BLACK);
    primaryStage.setTitle("Boxes");
    primaryStage.setScene(scene);
    primaryStage.show();
  }
  
  public static void main(String[] args) {
    launch(args);
  }
}
