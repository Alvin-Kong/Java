// Alvin Kong   Case ID: axk1079
// Homework 5 Problem 1
import java.util.Scanner;
public class Problem1 {
 public static void main(String[] args) {
  Scanner scan = new Scanner(System.in);
  int userInput;
  String allHTML = "";
  System.out.println("How many URLs?");
  userInput = scan.nextInt();
  String ignore = scan.nextLine();
  for (int i = 1; i <= userInput; i++) {
    System.out.println("Enter URL #" + i + ": ");
    String URL = scan.nextLine();
    System.out.println("Enter text for URL #" + i + ": ");
    String urlText = scan.nextLine();
    String newHTML =  "<a href = \"http://" + URL + "\">" + urlText + "</a><br>";
    allHTML = allHTML + newHTML + "\n";
  }
  System.out.println("Copy and paste the following HTML code into your editor:");
  System.out.println(allHTML);
 }
}