// Alvin Kong   Case ID: axk1079
// Homework 5 Problem 2
import java.util.Scanner;
public class Problem2 {
  public static void main (String[] args) {
    Scanner scan = new Scanner(System.in);
    int userNum;
    boolean prime;
    int divisor;
    System.out.println("Enter limit: ");
    userNum = scan.nextInt();
    for (int i = 2; i <= userNum; i++) {
      System.out.println(i + " is divisible by ");
      prime = true;
      for (int n = 2; n < i; n++) {
        divisor = n;
        if (i % divisor == 0 && i != n) {
          prime = false;
          System.out.println(divisor);
        }
      }  
      if (prime == true) {
          System.out.println("none (is prime)");
      }
    }
  }
}